# spec-esb
PHP based ESB

This is a middle layer which do validation, transformation and transportation of payload.

# Features
* Retry
* Rate limit

# Technology
* PHP Slim Framework
* Amazon SQS
* Amazon S3
* MySQL database
* Load Balancer / Autoscaling

# Coding conventions
## Handler Class
* Handler class must always extend \Spec\Handler\HandlerAbstract
* Handler class namespacing to follow **\Spec\Handler\[client|application]\\[docType][source][target]** 
example: **\Spec\Handler\UnderArmour\ShipmentWmsCms**
