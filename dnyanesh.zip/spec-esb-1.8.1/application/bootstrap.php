<?php

date_default_timezone_set("UTC");

ini_set("soap.wsdl_cache_enabled", "1");
ini_set("soap.wsdl_cache_ttl", "1800");
ini_set("soap.wsdl_cache_dir", sys_get_temp_dir());
//ini_set("soap.wsdl_cache", WSDL_CACHE_BOTH);
