<?php

/**
 * Entry point to invoke poller request.
 * This is only for CLI entry and not meant for web entry.
 * 
 * Parameters:
 * - `className`
 * -- MANDATORY for ALL
 * - `entityId`
 * -- MANDATORY for Poller
 * -- OPTIONAL for others
 * - `threadId`
 * -- MANDATORY for Poller
 * -- OPTIONAL for others
 * 
 * @author Harry Lesmana <harrylesmana@singpost.com>
 * @since 2018-07-18
 */
define("ROOT_PATH", realpath(__DIR__));

/* Require vendor autoload  */
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "vendor" . DIRECTORY_SEPARATOR . "autoload.php";
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "application" . DIRECTORY_SEPARATOR . "bootstrap.php";

$params = array(
    "debugFile"
);

for ($i = 1; $i < $argc; $i++) {
    list($key, $val) = explode("=", $argv[$i]);
    $params[$key] = $val;
}
try {
    $paramClassName = isset($params["className"]) ? $params["className"] : NULL;
    $paramEntityId = isset($params["entityId"]) ? $params["entityId"] : NULL;

    /* Check if `className` parameter is provided because this parameter is MANDATORY */
    if ($paramClassName === NULL) {
        throw new \Exception("Param `className` is not set");
    }
    /* Check for class existence */
    if (!class_exists($paramClassName)) {
        throw new \Exception("Class '{$paramClassName}' does not exist");
    }

    $payload = new \Spec\Model\Payload();
    $payload->setId($paramEntityId);
    foreach ($params as $key => $value) {
        if (!in_array($key, array("entityId", "className", "threadId"))) {
            $payload->addAttribute($key, $value);
        }
    }

    $handler = new $paramClassName($payload);
    $handler->execute();
} catch (\Exception $ex) {
    echo "PROBLEM ENCOUNTERED:" . PHP_EOL;
    echo $ex->getMessage() . PHP_EOL;
    echo $ex->getTraceAsString() . PHP_EOL;
}
