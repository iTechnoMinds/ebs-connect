<?php

/**
 * Debug Entry Point Script to test \Spec\Endpoint\EndpointAbstract derived class.
 * This script requires the existence of .body (payload) and .json (configuration) file with the same name of the script name present under Endpoint folder.
 * 
 * Parameters:
 * - `className` (MANDATORY)
 * - `entityId` (OPTIONAL) This value will convert into Payload ID
 * 
 * Example:
 * - Class Name to test is \Spec\Endpoint\Email.
 * - Payload file is /debug/Endpoint/Spec_Endpoint_Email.body.
 * - Configuration file is /debug/Endpoint/Spec_Endpoint_Email.json.
 * 
 * @author Harry Lesmana <harrylesmana@singpost.com>
 * @since 2018-08-28
 */
require_once "bootstrap.php";

$params = array(
    "debugFile"
);

for ($i = 1; $i < $argc; $i++) {
    list($key, $val) = explode("=", $argv[$i]);
    $params[$key] = $val;
}

$paramClassName = isset($params["className"]) ? $params["className"] : NULL;
$classNamePath = trim(trim(str_ireplace("\\", "_", $paramClassName)), "_");
trim($classNamePath);
trim($classNamePath, "_");

$paramEntityId = isset($params["entityId"]) ? $params["entityId"] : NULL;

/**
 * @var \Spec\Endpoint\EndpointAbstract Endpoint
 */
$endpoint = NULL;
try {
    /* Check if `className` parameter is provided because this parameter is MANDATORY */
    if ($paramClassName === NULL) {
        throw new \Exception("Param `className` is not set");
    }
    /* Check for class existence */
    if (!class_exists($paramClassName)) {
        throw new \Exception("Class '{$paramClassName}' does not exist");
    }

    $payloadFile = ROOT_PATH . DIRECTORY_SEPARATOR . "debug" . DIRECTORY_SEPARATOR . "Endpoint" . DIRECTORY_SEPARATOR . $classNamePath . ".body";
    $configurationFile = ROOT_PATH . DIRECTORY_SEPARATOR . "debug" . DIRECTORY_SEPARATOR . "Endpoint" . DIRECTORY_SEPARATOR . $classNamePath . ".json";
    $attributeFile = ROOT_PATH . DIRECTORY_SEPARATOR . "debug" . DIRECTORY_SEPARATOR . "Endpoint" . DIRECTORY_SEPARATOR . $classNamePath . ".attribute.json";

    $payload = new \Spec\Model\Payload();
    $payload->setId($paramEntityId);

    $endpointConfiguration = array();
    if (!file_exists($configurationFile)) {
        echo "[WARNING] Configuration file is not found '{$configurationFile}'" . PHP_EOL;
    } else {
        $endpointConfiguration = json_decode(file_get_contents($configurationFile), TRUE);
        echo "-- Payload Config: {$configurationFile}" . PHP_EOL . print_r($endpointConfiguration, TRUE) . PHP_EOL;
    }

    $payloadString = "";
    if (!file_exists($payloadFile)) {
        echo "[WARNING] Payload file is not found '{$payloadFile}'" . PHP_EOL;
    } else {
        $payloadString = file_get_contents($payloadFile);
        $payload->setContent($payloadString);
        echo "-- Payload Content: {$payloadFile}" . PHP_EOL . $payloadString . PHP_EOL;
    }

    /* Setting up configuration for the endpoint */
    $modelEndpointConfiguration = new \Spec\Model\EndpointConfig();
    $modelEndpointConfiguration->setType($endpointConfiguration["target.protocol"]);
    $modelEndpointConfiguration->setHost($endpointConfiguration["target.host"]);
    $modelEndpointConfiguration->setPort($endpointConfiguration["target.port"]);
    $modelEndpointConfiguration->setUser($endpointConfiguration["target.user"]);
    $modelEndpointConfiguration->setPass($endpointConfiguration["target.pass"]);
    $modelEndpointConfiguration->setPath($endpointConfiguration["target.path"]);
    $modelEndpointConfiguration->setConfigExtra($endpointConfiguration);
    $payload->setContentType($endpointConfiguration["target.content.type"]);

    $endpoint = new $paramClassName($modelEndpointConfiguration);
    $endpoint->put($payload);
} catch (\Exception $ex) {
    echo PHP_EOL . PHP_EOL;
    echo "PROBLEM ENCOUNTERED:" . PHP_EOL . $ex->getMessage() . PHP_EOL . $ex->getTraceAsString() . PHP_EOL;
} finally {
    if ($endpoint !== NULL && $endpoint instanceof \Spec\Endpoint\EndpointAbstract) {
        foreach ($endpoint->getEventLogs() as $eventLog) {
            echo "{$eventLog->getMessage()} [{$eventLog->getStatus()}]" . PHP_EOL;
        }
        echo PHP_EOL;
    }
}


