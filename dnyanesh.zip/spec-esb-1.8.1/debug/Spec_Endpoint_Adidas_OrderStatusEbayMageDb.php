<?php

/**
 * Debug script to test \Spec\Endpoint\Adidas\OrderStatusEbayMageDb class.
 * This script requires the existence of xml file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Endpoint_Adidas_OrderStatusEbayMageDb.php
 * /debug/Spec_Endpoint_Adidas_OrderStatusEbayMageDb.xml
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2016-03-23
 */
require_once "bootstrap.php";

$xmlFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$xml = file_get_contents($xmlFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($xml);

$config = new \Spec\Model\EndpointConfig();
$config->setHost("127.0.0.1");
$config->setPort("3306");
$config->setPath("midz_uat");
$config->setUser("root");
$config->setPass("");
//$configuration = array(
//                'host'     => '127.0.0.1',
//                'dbname'   => 'supplizer',
//                'username' => 'root',
//                'password' => '');
//
//echo "Configuration:" . PHP_EOL;
//echo json_encode($configuration) . PHP_EOL;

$endpoint = new \Spec\Endpoint\Adidas\OrderStatusEbayMageDb($config);
$endpoint->put($payload);

echo "Output:" . PHP_EOL;
echo $endpoint->getLastResponse() . PHP_EOL;
$outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT.xml";
file_put_contents($outputFile, $endpoint->getLastResponse());
echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
