<?php

/**
 * Debug script to test \Spec\Endpoint\CyberSource\Capture class.
 * @author Harry Lesmana <harrylesmana@singpost.com>
 * @since 2015-11-05
 */
require_once "bootstrap.php";

$payloadContent = <<<XML
<?xml version="1.0" encoding="utf-8"?>
<ShipmentUpdate>
	<OrderShipment>
		<VendorInfo>
			<VendorNumber>MYWH</VendorNumber>
			<VendorName>LF Logistics Services (M) Sdn Bhd</VendorName>
			<Address1>Lot 6, Persiaran Budiman</Address1>
			<City>Shah Alam</City>
			<PostalCode>40300</PostalCode>
			<CountryCode>MY</CountryCode>
			<Country>Malaysia</Country>
		</VendorInfo>
	</OrderShipment>
</ShipmentUpdate>
XML;

$payload = new \Spec\Model\Payload();
$payload->setContent($payloadContent);
$payload->setContentType("text/xml");

$config = new \Spec\Model\EndpointConfig();
$config->setHost("ap-southeast-1");
$config->setPort("spcommerce");
$config->setPath("test/outbound");
$config->setUser("");
$config->setPass("");

echo "Payload:" . PHP_EOL;
echo $payloadContent;
echo PHP_EOL;

echo "Configuration:" . PHP_EOL;
print_r($config);
echo PHP_EOL;

$endpoint = new \Spec\Endpoint\Aws\S3($config);
$endpoint->put($payload);

echo "Output:" . PHP_EOL;
echo $endpoint->getLastResponse() . PHP_EOL;

$outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT.xml";
file_put_contents($outputFile, $endpoint->getLastResponse());

echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
