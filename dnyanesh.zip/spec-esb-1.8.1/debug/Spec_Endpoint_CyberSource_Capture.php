<?php

/**
 * Debug script to test \Spec\Endpoint\CyberSource\Capture class.
 * @author Harry Lesmana <harrylesmana@singpost.com>
 * @since 2015-11-05
 */
require_once "bootstrap.php";

$payloadContent = array(
    "merchantReferenceCode" => uniqid(),
    "transactionId" => "4467280779585000001516",
    "captureToken" => "Ahj/7wSR5FfzELqsDp/YlFmjRs3ZOGDdu5auGrBgwYMGLVi2T+D/XwikBT+D/XwilWB+DgUvYZNJMt0gO+RIgokeRX8xC6rA6f2Agmck",
    "currency" => "HKD",
    "amount" => 248
);

$payload = new \Spec\Model\Payload();
$payload->setContent(json_encode($payloadContent));

$config = new \Spec\Model\EndpointConfig();
$config->setHost("ics2wstest.ic3.com");
$config->setPath("commerce/1.x/transactionProcessor/CyberSourceTransaction_1.78.wsdl");
$config->setUser("clarins_hongkong");
$config->setPass("UfxQCMRKcTklyMNc1XzpwVUwATMYYNm5S+bAb+46WOQuAGVWJfGIs5g3eJuyQwjI10IylXogiGFWLL51T3cxNAA70V0gkuB5ssK53P2GsqO3GkVdKrr6d12fw1QKthhhYT4kM4l2ErdOBorkZZnfC9rb4WIJlJVUdgOhlONEN/QGYGy65SGBol8B9mgG/OCm5iGFOFzwNnDeTF0m3MyzpVDn/7Rhgj1Xt0++rcjdCNSGi1Vzgv33ADePUVOYOpNpIt6by9dHf3bSyY4Q0Q1wqdU/qGMsHkEvkx4uy6iRxqIN1DdOyQCdmwvVIm1N02zXvjqpMoS+G/Qq0Vd8MWAC3Q==");

echo "Payload:" . PHP_EOL;
echo json_encode($payloadContent);
echo PHP_EOL;

echo "Configuration:" . PHP_EOL;
print_r($config);
echo PHP_EOL;

$endpoint = new \Spec\Endpoint\CyberSource\Capture($config);
$endpoint->put($payload);

echo "Output {$key}:" . PHP_EOL;
echo $endpoint->getLastResponse() . PHP_EOL;

$outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT.xml";
file_put_contents($outputFile, $endpoint->getLastResponse());

echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
