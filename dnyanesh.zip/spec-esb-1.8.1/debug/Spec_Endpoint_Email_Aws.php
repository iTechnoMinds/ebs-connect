<?php

/**
 * Debug script to test \Spec\Endpoint\CyberSource\Capture class.
 * @author Harry Lesmana <harrylesmana@singpost.com>
 * @since 2015-11-05
 */
require_once "bootstrap.php";

$htmlFile = __DIR__ . DIRECTORY_SEPARATOR . "Spec_Endpoint_Email.html";
$html = file_get_contents($htmlFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($html);

$config = new \Spec\Model\EndpointConfig();
$config->setHost("email-smtp.us-west-2.amazonaws.com");
$config->setUser("AKIAJGSXSPKHKDYJR4FQ");
$config->setPass("AoYHEmfWfJJ6+paK+DU64+tZEhdyH1ZTrznHM3xmMtiY");
$config->setPort("587");

echo "Configuration:" . PHP_EOL;
print_r($config);
echo PHP_EOL;

$endpoint = new \Spec\Endpoint\Email\Aws($config);
$endpoint->put($payload);

echo "Output:" . PHP_EOL;
echo $endpoint->getLastResponse() . PHP_EOL;

$outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT.xml";
file_put_contents($outputFile, $endpoint->getLastResponse());

echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
