<?php

/**
 * Debug script to test Spec\Endpoint\Lazada\Suntory\Http class.
 * This script requires the existence of json file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Endpoint_Lazada_Suntory_Http.php
 * /debug/Spec_Endpoint_Lazada_Suntory_Http.xml
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2020-10-21
 */
require_once "bootstrap.php";

$jsonFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$jsonPayloadContent = file_get_contents($jsonFile);
$requestParam['payload'] = $jsonPayloadContent;
//$requestParam['refresh_token'] = "50001600e06kZ0xnrc1c6038b6g7fVeqRErsEfhBrAo0WeoILKakTTmE251qwAVx";
$payload = new \Spec\Model\Payload();
$payload->setContent($requestParam);
$payload->setContentType("application/json");

$configuration = [
    "appKey" => "123221",
    "secretKey" => "RIXuLsGpYRN5e2jSza28vEbbWxmt54Fc",
    "accessToken" => "50000601b36sz4qdYeiy3Mt2EKdNI4jRuGg5lqxFLSawONYX1e809dd5AloIwWak",
    "refreshToken" => "50001601736iJpjqbuwlWDcyfPrxEojui2hzVBlbASThwPYR1543c200rj8xQfII",
    "requestApiName" => "product/price_quantity/update",
    //"requestApiName" => "auth/token/refresh",
    "refreshTokenApiName" => "auth/token/refresh",
    "outboundId" => "10080"
];


$config = new \Spec\Model\EndpointConfig();
$config->setHost("api.lazada.sg");
$config->setType("HTTPS");
$config->setPort(443);
$config->setPath("rest");
$config->setConfigExtra($configuration);

echo "Configuration:" . PHP_EOL;
echo"<pre>"; //print_r($config);echo"<br>";
echo PHP_EOL;

$endpoint = new \Spec\Endpoint\Lazada\Suntory\Http($config);

$endpoint->put($payload);

echo "Output:" . PHP_EOL;
echo $endpoint->getLastResponse() . PHP_EOL;

$outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT.xml";
file_put_contents($outputFile, $endpoint->getLastResponse());

echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
