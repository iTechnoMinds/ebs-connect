<?php

/**
 * Debug script to test \Spec\Endpoint\Mule\HjShipment class.
 * @author Harry Lesmana <harrylesmana@singpost.com>
 * @since 2016-03-21
 */
require_once "bootstrap.php";

$payloadFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$payloadContent = file_get_contents($payloadFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($payloadContent);
$payload->setContentType("text/xml");

$config = new \Spec\Model\EndpointConfig();
$config->setHost("");
$config->setPort("8601");
$config->setPath("register/shipment");
$config->setType("https");
$config->setUser("");
$config->setPass("");

echo "Configuration:" . PHP_EOL;
print_r($config);
echo PHP_EOL;

$endpoint = new \Spec\Endpoint\Mule\HjShipment($config);
$endpoint->put($payload);

echo "Output:" . PHP_EOL;
echo $endpoint->getLastResponse() . PHP_EOL;

$outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT.xml";
file_put_contents($outputFile, $endpoint->getLastResponse());

echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
