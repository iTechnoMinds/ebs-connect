<?php

/**
 * Debug script to test \Spec\Endpoint\Sftp class.
 * @author Danyanesh Telgad <dnyaneshwarte@cybage.com>
 * @since 2016-03-17
 */
require_once "bootstrap.php";

$payloadFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".txt";
$payloadContent = file_get_contents($payloadFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($payloadContent);
$payload->setExternalName("20160322095238.txt");

$config = new \Spec\Model\EndpointConfig();
$config->setHost("");
$config->setPort("22");
$config->setPath("");
$config->setUser("");
$config->setPass("");
$config->setType("sftp");

echo "Configuration:" . PHP_EOL;
var_dump($config);
echo PHP_EOL;

$endpoint = new \Spec\Endpoint\Sftp($config);
$endpoint->put($payload);

echo "Output:" . PHP_EOL;
echo $endpoint->getLastResponse() . PHP_EOL;

$outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT.xml";
file_put_contents($outputFile, $endpoint->getLastResponse());

echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
