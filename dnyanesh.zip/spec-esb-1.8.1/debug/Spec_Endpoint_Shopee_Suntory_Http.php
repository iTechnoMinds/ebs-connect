<?php

/**
 * Debug script to test Spec\Endpoint\Shopee\Suntory\SuntoryFlexShopee class.
 * This script requires the existence of json file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Endpoint_Shopee_Suntory_SuntoryFlexShopee.php
 * /debug/Spec_Endpoint_Shopee_Suntory_SuntoryFlexShopee.json
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2020-10-14
 */
require_once "bootstrap.php";

$jsonFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".json";
$jsonPayloadContent = file_get_contents($jsonFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($jsonPayloadContent);
$payload->setContentType("application/json");

$configuration = [
    "secret" => "2e5d48c94a95008d3d7a09b7c67408dfdcc1efa0b9b21896ea7e079d2bb7967e",
    "partner_id" => 846508,
    "shopid" => 292087069
];

$config = new \Spec\Model\EndpointConfig();
$config->setHost("partner.shopeemobile.com");
$config->setType("HTTPS");
//$config->setPath("api/v1/items/update_stock");
$config->setPath("api/v1/items/update/items_stock");
//$config->setPath("api/v1/orders/basics");
$config->setConfigExtra($configuration);

echo "Configuration:" . PHP_EOL;
echo"<pre>"; //print_r($config);echo"<br>";
echo PHP_EOL;

$endpoint = new \Spec\Endpoint\Shopee\Suntory\Http($config);
$endpoint->put($payload);

echo "Output:" . PHP_EOL;
echo $endpoint->getLastResponse() . PHP_EOL;

$outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT.xml";
file_put_contents($outputFile, $endpoint->getLastResponse());

echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
