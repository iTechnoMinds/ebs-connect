<?php

/**
 * Debug script to test \Spec\Endpoint\Supplizer\ListenerShipment.
 * @author Harry Lesmana <harrylesmana@singpost.com>
 * @since 2017-02-16
 */
require_once "bootstrap.php";

$payloadFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$payloadContent = file_get_contents($payloadFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($payloadContent);
$payload->setContentType("text/xml");

$configExtra = [
    "checkShipmentExist" => TRUE,
    "checkShipmentExistParam" => [
        "client" => "SPWMS",
        "key" => "7172936ecea94d06bf82035f331cadaf"
    ]
];
$config = new \Spec\Model\EndpointConfig();
$config->setHost("timberlandsgwsuat.specom.io");
$config->setPort("443");
$config->setPath("adidas/listenerShipment");
$config->setType("https");
$config->setUser("");
$config->setPass("");
$config->setConfigExtra($configExtra);

echo "Configuration:" . PHP_EOL;
print_r($config);
echo PHP_EOL;

$endpoint = new \Spec\Endpoint\Supplizer\ListenerShipment($config);
$endpoint->put($payload);

echo "Output:" . PHP_EOL;
echo $endpoint->getLastResponse() . PHP_EOL;

$outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT.xml";
file_put_contents($outputFile, $endpoint->getLastResponse());

echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
