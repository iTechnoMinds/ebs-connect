<?php

/**
 * Debug script to test \Spec\Endpoint\Wms\Http127 class.
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2016-02-05
 */
require_once "bootstrap.php";

$payloadFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".json";
$payloadContent = file_get_contents($payloadFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($payloadContent);
$payload->setContentType("application/json");

$config = new \Spec\Model\EndpointConfig();
$config->setHost("dev.huper.asia");
$config->setPath("api/OrderApi/CreateOrderByImportSingPostMethod?token=1234567890abcdef");

echo "Configuration:" . PHP_EOL;
echo"<pre>";//print_r($config);echo"<br>";
echo PHP_EOL;

$endpoint = new \Spec\Endpoint\Uniqlo\SG\ShipmentHjHuper($config);
$endpoint->put($payload);

echo "Output:" . PHP_EOL;
echo $endpoint->getLastResponse() . PHP_EOL;

$outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT.xml";
file_put_contents($outputFile, $endpoint->getLastResponse());

echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
