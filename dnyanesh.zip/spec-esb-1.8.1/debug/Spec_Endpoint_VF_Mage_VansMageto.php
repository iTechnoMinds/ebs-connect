<?php

/**
 * Debug script to test Spec\Endpoint\VF\Mage\VansMageto class.
 * This script requires the existence of json file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Endpoint_VF_Mage_VansMageto.php
 * /debug/Spec_Endpoint_VF_Mage_VansMageto.json
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2020-04-28
 */
require_once "bootstrap.php";

$jsonFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".json";
$jsonPayloadContent = file_get_contents($jsonFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($jsonPayloadContent);
$payload->setContentType("application/json");

$configuration = [
    "username" => "vansuat",
    "password" => "vans@123",
    "tokenURL" => "https://vanssgstg.specom.io/rest/V1/integration/admin/token"
];

$config = new \Spec\Model\EndpointConfig();
$config->setHost("vanssgstg.specom.io");
$config->setType("HTTPS");
$config->setPath("rest/V1/order/order_entity_id/invoice");
$config->setConfigExtra($configuration);

echo "Configuration:" . PHP_EOL;
echo"<pre>"; //print_r($config);echo"<br>";
echo PHP_EOL;

$endpoint = new \Spec\Endpoint\VF\Mage\VansMageto($config);
$endpoint->put($payload);

echo "Output:" . PHP_EOL;
echo $endpoint->getLastResponse() . PHP_EOL;

$outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT.xml";
file_put_contents($outputFile, $endpoint->getLastResponse());

echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
