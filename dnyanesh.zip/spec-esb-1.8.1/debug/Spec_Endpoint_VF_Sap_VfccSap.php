<?php

/**
 * Debug script to test Spec\Endpoint\VF\Sap\VfccSap class.
 * This script requires the existence of json file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Endpoint_VF_Sap_SalesReturnsDataSap.php
 * /debug/Spec_Endpoint_VF_Sap_SalesReturnsDataSap.json
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2020-04-28
 */
require_once "bootstrap.php";

$jsonFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".json";
$jsonPayloadContent = file_get_contents($jsonFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($jsonPayloadContent);
$payload->setContentType("application/json");

$configuration = [
    "oauth2ClientId" => "5067b776897c43cea93b83eb9d6e1b11",
    "oauth2ClientSecret" => "7390a6F0e3584a61bD5c2070B1837428",
    "tokenURL" => "https://vf-api-sb-apac-oauth2-mule3.sg-s1.cloudhub.io/external/access_token",
    "storesPathMap" => ["006091" => "HK/VAN/006091", "006092" => "SG/VAN/006092", "006093" => "MY/VAN/006093", "006094" => "PH/VAN/006094", "006095" => "ID/VAN/006095", "006096" => "TH/VAN/006096"],
  
];

$config = new \Spec\Model\EndpointConfig();
$config->setHost("vf-api-sb-apac-cm-exp.sg-s1.cloudhub.io");
$config->setType("HTTPS");
$config->setPath("v1/sales-and-returns");
$config->setConfigExtra($configuration);

echo "Configuration:" . PHP_EOL;
echo"<pre>"; //print_r($config);echo"<br>";
echo PHP_EOL;

$endpoint = new \Spec\Endpoint\VF\Sap\VfccSap($config);
$endpoint->put($payload);

echo "Output:" . PHP_EOL;
echo $endpoint->getLastResponse() . PHP_EOL;

$outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT.xml";
file_put_contents($outputFile, $endpoint->getLastResponse());

echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
