<?php

/**
 * Debug script to test \Spec\Endpoint\Wms\Http127 class.
 * @author Harry Lesmana <harrylesmana@singpost.com>
 * @since 2016-02-05
 */
require_once "bootstrap.php";

$payloadFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$payloadContent = file_get_contents($payloadFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($payloadContent);

$config = new \Spec\Model\EndpointConfig();
$config->setHost("test.specom.local");
$config->setPort("80");
$config->setPath("test-wms-endpoint.php");

echo "Configuration:" . PHP_EOL;
print_r($config);
echo PHP_EOL;

$endpoint = new \Spec\Endpoint\Wms\Http127($config);
$endpoint->put($payload);

echo "Output:" . PHP_EOL;
echo $endpoint->getLastResponse() . PHP_EOL;

$outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT.xml";
file_put_contents($outputFile, $endpoint->getLastResponse());

echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
