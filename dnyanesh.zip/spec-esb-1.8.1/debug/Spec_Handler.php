<?php

/**
 * Debug Entry Point Script to test \Spec\Handler\HandlerAbstract derived class.
 * This script requires the existence of .body (payload) and .json (configuration) file with the same name of the script name present under Handler folder.
 * 
 * Parameters:
 * - `className` (MANDADTORY)
 * - `entityId` (OPTIONAL) This value will convert into Payload ID
 * 
 * Example:
 * - Class Name to test is \Spec\Handler\Uniqlo\AU\OrderMagentoSupplizerEnricher.
 * - Payload file is /debug/Handler/Spec_Handler_Uniqlo_AU_OrderMagentoSupplizerEnricher.body.
 * - Configuration file is /debug/Handler/Spec_Handler_Uniqlo_AU_OrderMagentoSupplizerEnricher.json.
 * 
 * @author Harry Lesmana <harrylesmana@singpost.com>
 * @since 2018-07-17
 */
require_once "bootstrap.php";

$params = array(
    "debugFile"
);

for ($i = 1; $i < $argc; $i++) {
    list($key, $val) = explode("=", $argv[$i]);
    $params[$key] = $val;
}

$paramClassName = isset($params["className"]) ? $params["className"] : NULL;
$classNamePath = trim(trim(str_ireplace("\\", "_", $paramClassName)), "_");

$paramEntityId = isset($params["entityId"]) ? $params["entityId"] : NULL;

$handler = NULL;
try {
    /* Check if `className` parameter is provided because this parameter is MANDATORY */
    if ($paramClassName === NULL) {
        throw new \Exception("Param `className` is not set");
    }
    /* Check for class existence */
    if (!class_exists($paramClassName)) {
        throw new \Exception("Class '{$paramClassName}' does not exist");
    }

    $payloadFile = ROOT_PATH . DIRECTORY_SEPARATOR . "debug" . DIRECTORY_SEPARATOR . "Handler" . DIRECTORY_SEPARATOR . $classNamePath . ".body";
    $configurationFile = ROOT_PATH . DIRECTORY_SEPARATOR . "debug" . DIRECTORY_SEPARATOR . "Handler" . DIRECTORY_SEPARATOR . $classNamePath . ".json";
    $attributeFile = ROOT_PATH . DIRECTORY_SEPARATOR . "debug" . DIRECTORY_SEPARATOR . "Handler" . DIRECTORY_SEPARATOR . $classNamePath . ".attribute.json";

    $payload = new \Spec\Model\Payload();
    $payload->setId($paramEntityId);

    $handlerConfiguration = array();
    if (!file_exists($configurationFile)) {
        echo "[WARNING] Configuration file is not found '{$configurationFile}'" . PHP_EOL;
    } else {
        $handlerConfiguration = json_decode(file_get_contents($configurationFile), TRUE);
        echo "-- Payload Config: {$configurationFile}" . PHP_EOL . print_r($handlerConfiguration, TRUE) . PHP_EOL;
    }

    $handlerAttributeList = array();
    if (!file_exists($attributeFile)) {
        echo "[WARNING] Attribute file is not found '{$attributeFile}'" . PHP_EOL;
    } else {
        $handlerAttributeList = json_decode(file_get_contents($attributeFile), TRUE);
        foreach ($handlerAttributeList as $attributeKey => $attributeValue) {
            $payload->addAttribute($attributeKey, $attributeValue);
        }
        echo "-- Payload Attribute: {$attributeFile}" . PHP_EOL . print_r($handlerAttributeList, TRUE) . PHP_EOL;
    }

    $payloadString = "";
    if (!file_exists($payloadFile)) {
        echo "[WARNING] Payload file is not found '{$payloadFile}'" . PHP_EOL;
    } else {
        $payloadString = file_get_contents($payloadFile);
        $payload->setContent($payloadString);
        echo "-- Payload Content: {$payloadFile}" . PHP_EOL . $payloadString . PHP_EOL;
    }

    $handler = new $paramClassName($payload);
    $handler->setProcessConfiguration($handlerConfiguration);
    $handler->execute();

    foreach ($handler->getPayloadChild() as $key => $child) {
        $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.body";
        file_put_contents($outputFile, $child->getContent());

        echo "OUTPUT {$key} >> START" . PHP_EOL;
        echo $child->getContent() . PHP_EOL;
        echo "OUTPUT {$key} << END" . PHP_EOL;
        echo "ID: '{$child->getExternalId()}' Written to '{$outputFile}'" . PHP_EOL . PHP_EOL;
    }
} catch (\Exception $ex) {
    echo PHP_EOL . PHP_EOL;
    echo "PROBLEM ENCOUNTERED:" . PHP_EOL . $ex->getMessage() . PHP_EOL . $ex->getTraceAsString() . PHP_EOL;
} finally {
    /* Display Event Logs from the Implementation Class */
    if ($handler !== NULL && $handler instanceof \Spec\Handler\HandlerAbstract)
        foreach ($handler->getEventLogs() as $eventLog) {
            echo "{$eventLog->getMessage()} [{$eventLog->getStatus()}]" . PHP_EOL . PHP_EOL;
        }
}


