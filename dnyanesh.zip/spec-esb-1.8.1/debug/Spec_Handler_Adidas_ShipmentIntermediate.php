<?php

/**
 * Debug script to test \Spec\Handler\Adidas\ShipmentIntermediate class.
 * This script requires the existence of csv file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Handler_Adidas_ShipmentIntermediate.php
 * /debug/Spec_Handler_Adidas_ShipmentIntermediate.csv
 * @author Harry Lesmana <harrylesmana@singpost.com>
 * @since 2016-02-15
 */
require_once "bootstrap.php";

$contentFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$content = file_get_contents($contentFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($content);

$configuration = [
    "filter" => [
        "ShipmentType" => [
            \Spec\Handler\Adidas\ShipmentIntermediate::SHIPMENT_TYPE_ASSIGNMENT,
            \Spec\Handler\Adidas\ShipmentIntermediate::SHIPMENT_TYPE_TRANSIT
        ]
    ]
];

echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;

$handler = new \Spec\Handler\Adidas\ShipmentIntermediate($payload);
$handler->setProcessConfiguration($configuration);
$handler->execute();

foreach ($handler->getPayloadChild() as $key => $child) {
    echo "Output {$key}:" . PHP_EOL;
    echo $child->getContent() . PHP_EOL;

    $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.xml";
    file_put_contents($outputFile, $child->getContent());

    echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
}
