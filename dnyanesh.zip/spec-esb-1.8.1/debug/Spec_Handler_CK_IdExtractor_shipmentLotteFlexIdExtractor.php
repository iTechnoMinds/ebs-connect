<?php

/**
 * Debug script to test Spec\Handler\CKIdExtractor\shipmentLotteFlexIdExtractor class.
 * This script requires the existence of csv file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Handler_CK_IdExtractor_shipmentLotteFlexIdExtractor.php
 * /debug/Spec_Handler_CK_IdExtractor_shipmentLotteFlexIdExtractor.json
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2020-11-20
 */
require_once "bootstrap.php";

$jsonFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".csv";
$json = file_get_contents($jsonFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($json);
$payload->setId(480700);
//23016
$configuration = [
    "idType"=> "lotteflex-shipment-id"
];

echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;

$handler = new \Spec\Handler\CK\IdExtractor\shipmentLotteFlexIdExtractor($payload);
$handler->setProcessConfiguration($configuration);
$handler->execute();

foreach ($handler->getPayloadChild() as $key => $child) {
    echo "Output {$key}:" . PHP_EOL;
    echo $child->getContent() . PHP_EOL;

    $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.xml";
    file_put_contents($outputFile, $child->getContent());

    echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
}
