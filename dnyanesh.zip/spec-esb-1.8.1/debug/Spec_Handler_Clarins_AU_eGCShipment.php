<?php

/**
 * Debug script to test \Spec\Handler\Clarins\AU\eGCShipment class.
 * This script requires the existence of xml file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Handler_Clarins_AU_eGCShipment.php
 * /debug/Spec_Handler_Clarins_AU_eGCShipment.xml
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2018-12-13
 */
require_once "bootstrap.php";

$xmlFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$xml = file_get_contents($xmlFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($xml);

$configuration = [
    "config" => [
        "immediate-ship-context-id" => "11005",
        "wms-context-id" => "10900",
        "eGcSku" => "999888"
    ]
];

echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;

$handler = new \Spec\Handler\Clarins\AU\eGCShipment($payload);

$handler->setProcessConfiguration($configuration);
$handler->execute();

foreach ($handler->getPayloadChild() as $key => $child) {
    echo "Output {$key}:" . PHP_EOL;
    echo $child->getContextId() . PHP_EOL;

    $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.xml";
    file_put_contents($outputFile, $child->getContent());

    echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
}
