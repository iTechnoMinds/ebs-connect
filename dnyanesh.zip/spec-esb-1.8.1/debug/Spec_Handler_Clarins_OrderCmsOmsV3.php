<?php

/**
 * Debug script to test \Spec\Handler\Demandware\OrderCmsOmsV3 class.
 * This script requires the existence of xml file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Handler_Clarins_OrderCmsOmsV3.php
 * /debug/Spec_Handler_Clarins_OrderCmsOmsV3.xml
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2018-12-13
 */
require_once "bootstrap.php";

$xmlFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$xml = file_get_contents($xmlFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($xml);

$configuration = [
    "config" => [
        "storeUrl" => "http://www.example.com",
        "storeCode" => "CLAU",
        "storeId" => "88",
        "storeName" => "Example",
        "itemCatalogCode" => "CLAU",
        "eGcProductId" => "999888",
        "eGcSku" => "999888"
    ]
];

echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;

$handler = new \Spec\Handler\Clarins\OrderCmsOmsV3($payload);
$handler->setProcessConfiguration($configuration);
$handler->execute();

foreach ($handler->getPayloadChild() as $key => $child) {
    echo "Output {$key}:" . PHP_EOL;
    echo $child->getContent() . PHP_EOL;

    $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.xml";
    file_put_contents($outputFile, $child->getContent());

    echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
}
