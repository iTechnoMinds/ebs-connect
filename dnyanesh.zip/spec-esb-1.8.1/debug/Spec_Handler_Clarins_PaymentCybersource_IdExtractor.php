<?php

/**
 * Debug script to test \Spec\Handler\Clarins\PaymentCybersource\IdExtractor class.
 * This script requires the JSON string as input payload
 * @author Dnyanesh Telgad <dnyaneshwarte@cybage.com>
 * @since 2017-04-11
 */
require_once "bootstrap.php";

$payloadFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".json";
$jsonString = file_get_contents($payloadFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($jsonString);
$payload->setId(480700);

$configuration = [];

echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;

try {
    $handler = new \Spec\Handler\Clarins\PaymentCybersource\IdExtractor($payload);
    $handler->setProcessConfiguration($configuration);
    $handler->execute();
} catch (\Exception $ex) {
    
} finally {
    foreach ($handler->getExternalId() as $externalId) {
        echo "{$externalId['type']}: {$externalId['external_id']}" . PHP_EOL;
    }
}

