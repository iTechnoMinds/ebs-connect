<?php

/**
 * Debug script to test \Spec\Handler\Core\ReleaseHold class.
 * This script requires the existence of xml file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Handler_Core_ReleaseHold.php
 * /debug/Spec_Handler_Core_ReleaseHold.xml
 * @author Harry Lesmana <harrylesmana@singpost.com>
 * @since 2018-01-15
 */
require_once "bootstrap.php";

$configuration = [
];
echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;

try {
    $xmlFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
    $xml = file_get_contents($xmlFile);

    $payload = new \Spec\Model\Payload();
    $payload->setContent($xml);

    $handler = new \Spec\Handler\Core\ReleaseHold($payload);
    $handler->setProcessConfiguration($configuration);
    $handler->execute();

    foreach ($handler->getPayloadChild() as $key => $child) {
        echo "Output {$key}:" . PHP_EOL;
        echo $child->getContent() . PHP_EOL;

        $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.xml";
        file_put_contents($outputFile, $child->getContent());

        echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
    }
} catch (\Exception $ex) {
    echo $ex->getMessage() . PHP_EOL;
}

try {
    echo PHP_EOL . "SECOND RUN" . PHP_EOL;
    $modelAction = new \Spec\Model\Core\Action\PayloadRelease();
    $modelAction->setPayloadId(10000);
    $modelAction->setTargetStatus("RJX");

    $payload = new \Spec\Model\Payload();
    $payload->setId(10000);
    $payload->setContent($modelAction->asSimpleXMLElement()->asXML());

    $handler = new \Spec\Handler\Core\ReleaseHold($payload);
    $handler->setProcessConfiguration($configuration);
    $handler->execute();
} catch (\Exception $ex) {
    echo $ex->getMessage() . PHP_EOL;
}
