<?php

/**
 * Debug script to test \Spec\Handler\CyberSource\GetPaymentStatus class.
 * @author Dnyanesh Telgad <dnyaneshwarte@cybage.com>
 * @since 2020-01-16
 */
require_once "bootstrap.php";

//$payloadContent = array(
//    "merchantReferenceNumber" => "200881765",
//    "targetDate" => "20200113"
//);
$payloadContent = array(
    "requestID" => "clientReferenceInformation.code:201266864 AND submitTimeUtc:[NOW/DAY-7DAYS TO NOW/DAY+1DAY}"    
);

$payload = new \Spec\Model\Payload();
$payload->setContent(json_encode($payloadContent));

echo "Payload:" . PHP_EOL;
echo json_encode($payloadContent);
echo PHP_EOL;

/*for production url runEnv = cyberSource.environment.PRODUCTION 
*for test url runEnv = cyberSource.environment.SANDBOX
*
*/

$configuration = [
    "cybersource" => [
        "merchantId" => "karuppaiah",        
        "apiKeyID" => "4e4ebc5e-5d6e-4fa2-90d0-a179904a5fe5",
        "secretKey" => "Guh71nxdm2STeNKjb+Fl76DZzpgvBxKguoznOTWzwD8=",
        "runEnv" => "cyberSource.environment.SANDBOX",
        "statusCode" => "SOK"
    ]
];
           
echo "Configuration:" . PHP_EOL;
echo json_encode($configuration);
echo PHP_EOL;

$handler = new \Spec\Handler\CyberSourceRestfull\GetPaymentStatus($payload);
$handler->setProcessConfiguration($configuration);
$result = $handler->execute();

echo"<pre>";print_r($handler->getResult());