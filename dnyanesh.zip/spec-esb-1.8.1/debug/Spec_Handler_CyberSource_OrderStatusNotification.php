<?php

/**
 * Debug script to test \Spec\Handler\CyberSource\OrderStatusNotification class.
 * This script requires the existence of xml file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Handler_CyberSource_OrderStatusNotification.php
 * /debug/Spec_Handler_CyberSource_OrderStatusNotification.xml
 * @author Harry Lesmana <harrylesmana@singpost.com>
 * @since 2018-01-15
 */
require_once "bootstrap.php";

/**
 * @todo Get the order status notification XML sample from CyberSource.
 */
$xmlFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$xml = file_get_contents($xmlFile);

$configuration = [
    "OriginContextId" => 15700,
    "ExternalIdType" => "web-order-id"
];
echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;

$payload = new \Spec\Model\Payload();
$payload->setContent($xml);

$handler = new \Spec\Handler\CyberSource\OrderStatusNotification($payload);
$handler->setProcessConfiguration($configuration);
$handler->setManualCmsOrderNumberToRelease("DV064304");
$handler->execute();

foreach ($handler->getPayloadChild() as $key => $child) {
    echo "Output {$key}:" . PHP_EOL;
    echo $child->getContent() . PHP_EOL;

    $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.xml";
    file_put_contents($outputFile, $child->getContent());

    echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
}
