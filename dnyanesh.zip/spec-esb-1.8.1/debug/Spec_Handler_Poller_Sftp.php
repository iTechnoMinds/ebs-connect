<?php

/**
 * Debug script to test \Spec\Handler\Pller\Sftp class.
 * Example:
 * /debug/Spec_Handler_Poller_Sftp 
 * @author Dnyanesh Telgad <dnyaneshwarte@cybage.com>
 * @since 2018-07-10
 */
require_once "bootstrap.php";

$xmlFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".csv";
$xml = file_get_contents($xmlFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($xml);

$configuration = [
    'remote' => [
        'host' => '54.251.132.201',
        'port' => '22',
        'user' => 'uf_sg_my',
        'pass' => 'J3ljipFIM3PV',
        'path' => '/uploads/test/other/Dnyanesh',
        'filePattern' => 'Handler',
        'isDeleteAfterDownload' => false]
];

echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;


$handler = new \Spec\Handler\Poller\Sftp($payload);
$handler->setProcessConfiguration($configuration);
$handler->execute();

foreach ($handler->getPayloadChild() as $key => $child) {
    $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.xml";
    file_put_contents($outputFile, $child->getContent());

    echo "Output {$key} [{$child->getExternalId()}]; Written '{$outputFile}'" . PHP_EOL . PHP_EOL;
    echo $child->getContent() . PHP_EOL;
}