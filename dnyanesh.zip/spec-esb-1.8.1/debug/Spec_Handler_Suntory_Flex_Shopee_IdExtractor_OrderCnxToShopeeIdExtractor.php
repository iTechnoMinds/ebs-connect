<?php

/**
 * Debug script to test \Spec\Handler\Suntory\Flex\Shopee\IdExtractor\OrderCnxToShopeeIdExtractor class.
 * This script requires the existence of json file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Handler_Suntory_Flex_Shopee_IdExtractor_OrderCnxFlexShopeeIdExtractor.php
 * /debug/Spec_Handler_Suntory_Flex_Shopee_IdExtractor_OrderCnxFlexShopeeIdExtractor.json
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2021-02-17
 */
require_once "bootstrap.php";

$jsonFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".json";
$json = file_get_contents($jsonFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($json);

$configuration = [
    "idType" => "wms-cnx-order-no"
   
];

echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;

$handler = new Spec\Handler\Suntory\Flex\Shopee\IdExtractor\OrderCnxToShopeeIdExtractor($payload);
$handler->setProcessConfiguration($configuration);
$handler->execute();

foreach ($handler->getPayloadChild() as $key => $child) {
    echo "Output {$key}:" . PHP_EOL;
    echo $child->getContent() . PHP_EOL;

    $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.xml";
    file_put_contents($outputFile, $child->getContent());

    echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
}
