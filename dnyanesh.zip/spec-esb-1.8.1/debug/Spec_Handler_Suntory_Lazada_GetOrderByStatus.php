<?php

/**
 * Debug script to test \Spec\Handler\Adidas\Shipment class.
 * This script requires the existence of csv file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Handler_Adidas_Shipment.php
 * /debug/Spec_Handler_Adidas_Shipment.csv
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2015-11-25
 */
require_once "bootstrap.php";
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "debug" . DIRECTORY_SEPARATOR . "lazada" . DIRECTORY_SEPARATOR . "Constants.php";
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "debug" . DIRECTORY_SEPARATOR . "lazada" . DIRECTORY_SEPARATOR . "LazopClient.php";
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "debug" . DIRECTORY_SEPARATOR . "lazada" . DIRECTORY_SEPARATOR . "LazopLogger.php";
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "debug" . DIRECTORY_SEPARATOR . "lazada" . DIRECTORY_SEPARATOR . "LazopRequest.php";
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "debug" . DIRECTORY_SEPARATOR . "lazada" . DIRECTORY_SEPARATOR . "UrlConstants.php";

$csvFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$csv = file_get_contents($csvFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($csv);
$configuration = [
    "gatewayUrl" => "https://api.lazada.sg/rest",
    "appKey" => "122133",
    "secretKey" => "tQ4SbwxIEgqqno63Rrto9bJAUmIUAOzT ",
    "authUrl" => "https://auth.lazada.com/rest",
    "authCode" => "0_122133_2yuT4vV2rZnrSjO4RE6mIpTM18631",
    "accessToken" => "50000101500b1c32dcceVlvdjsDTTcaDBydstuifINIxjSvnjYBqobNrZma7N3Rq",
    "refreshToken" => "50001100100c19334c60SexTpcERzduiIIN3oqfYdjVenRcVvEZdaq7nVqR05R3x",
];


$lazopClient = new \Lazada\LazopClient($configuration['gatewayUrl'], $configuration['appKey'], $configuration['secretKey']);
$lazopRequest = new \Lazada\LazopRequest('/auth/token/refresh');
$lazopRequest->addApiParam('refresh_token', $configuration['refreshToken']);

var_dump($lazopClient->execute($lazopRequest));
exit;

echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;

$handler = new Spec\Handler\Suntory\Lazada\GetOrderByStatus($payload);
$handler->setProcessConfiguration($configuration);
$handler->execute();

foreach ($handler->getPayloadChild() as $key => $child) {
    echo "Output {$key}:" . PHP_EOL;
    echo $child->getContent() . PHP_EOL;

    $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.xml";
    file_put_contents($outputFile, $child->getContent());

    echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
}
