<?php

/**
 * Debug script to test \Spec\Handler\Suntory\Shopee\Flex\OrderCnxShopeeFlex class.
 * This script requires the existence of json file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Handler_Suntory_Shopee_Flex_OrderCnxShopeeFlex.php
 * /debug/Spec_Handler_Suntory_Shopee_Flex_OrderCnxShopeeFlex.json
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2021-02-22
 */
require_once "bootstrap.php";

$xmlFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".json";
$xml = file_get_contents($xmlFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($xml);

$configuration = [
    "accountId" => "Shopee",
    "warehouseCode" => "BCO"
];




echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;

$handler = new \Spec\Handler\Suntory\Shopee\Flex\OrderCnxShopeeFlex($payload);
$handler->setProcessConfiguration($configuration);
$handler->execute();

foreach ($handler->getPayloadChild() as $key => $child) {
    echo "Output {$key}:" . PHP_EOL;
    echo $child->getContent() . PHP_EOL;

    $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.xml";
    file_put_contents($outputFile, $child->getContent());

    echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
}
