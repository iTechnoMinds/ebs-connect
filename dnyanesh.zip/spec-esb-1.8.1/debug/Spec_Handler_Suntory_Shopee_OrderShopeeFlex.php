<?php

/**
 * Debug script to test \Spec\Handler\Suntory\Shopee\OrderShopeeFlex clsss
 * This script requires the existence of csv file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Handler_Adidas_Shipment.php
 * /debug/Spec_Handler_Adidas_Shipment.csv
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2015-11-25
 */
require_once "bootstrap.php";

$xmlFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$xml = file_get_contents($xmlFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($xml);

$configuration = [
    "username" => "***",
    "password" => "**!",
    "secret" => "***",
    "partner_id" => 846508,
    "shopid" => 292087069,
    "endpoint" => "partner.shopeemobile.com",
    "action" => "api/v1/orders", 
    "interval_minute" => 700
];



$handler = new \Spec\Handler\Suntory\Shopee\OrderShopeeFlex($payload);
$handler->setProcessConfiguration($configuration);
$handler->execute();

foreach ($handler->getPayloadChild() as $key => $child) {
    echo "Output {$key}:" . PHP_EOL;
    echo $child->getContent() . PHP_EOL;
    $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.xml";
    file_put_contents($outputFile, $child->getContent());
    echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
}
