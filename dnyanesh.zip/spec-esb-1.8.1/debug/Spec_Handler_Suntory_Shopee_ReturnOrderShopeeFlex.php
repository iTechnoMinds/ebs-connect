<?php

/**
 * Debug script to test \Spec\Handler\Suntory\Shopee\ReturnOrderShopeeFle clsss
 * This script requires the existence of csv file with the same name of the script name present in the same folder.
 * Example:
 * /debug/\Spec\Handler\Suntory\Shopee\ReturnOrderShopeeFle.php
 * /debug/\Spec\Handler\Suntory\Shopee\ReturnOrderShopeeFle.csv
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2021-04-22
 */
require_once "bootstrap.php";

$xmlFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$xml = file_get_contents($xmlFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($xml);

$configuration = [
    "username" => "sp_suntory_pmo@specom.io",
    "password" => "Suntory001!",
    "order_status" => "CANCELLED",
    "secret" => "2e5d48c94a95008d3d7a09b7c67408dfdcc1efa0b9b21896ea7e079d2bb7967e",
    "partner_id" => 846508,
    "shopid" => 122389443,
    "endpoint" => "partner.shopeemobile.com",
    "action" => "api/v1/returns/get",
   // "action" => "api/v1/orders/get",
    "interval_minute" => 100000
];
//$configuration = [
//    "username" => "sp_suntory_pmo@specom.io",
//    "password" => "Suntory001!",
//    "pagination_offset" => 4000,
//    "pagination_entries_per_page" => 100,
//    "secret" => "2e5d48c94a95008d3d7a09b7c67408dfdcc1efa0b9b21896ea7e079d2bb7967e",
//    "partner_id" => 846508,
//    "shopid" => 122389443,
//    "endpoint" => "partner.shopeemobile.com",
//    "action" => "api/v1/item/get",
//    "interval_minute" => 100000000
//];


$handler = new \Spec\Handler\Suntory\Shopee\ReturnOrderShopeeFlex($payload);
$handler->setProcessConfiguration($configuration);
$handler->execute();

foreach ($handler->getPayloadChild() as $key => $child) {
    echo "Output {$key}:" . PHP_EOL;
    echo $child->getContent() . PHP_EOL;
    $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.xml";
    file_put_contents($outputFile, $child->getContent());
    echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
}
