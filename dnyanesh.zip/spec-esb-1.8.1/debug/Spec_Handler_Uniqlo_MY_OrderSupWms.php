<?php

/**
 * Debug script to test \Spec\Handler\Uniqlo\MY\OrderSupWms class.
 * This script requires the existence of xml file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Handler_Uniqlo_MY_OrderSupWms.php
 * /debug/Spec_Handler_Uniqlo_MY_OrderSupWms.xml
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2017-06-12
 */
require_once "bootstrap.php";

$xmlFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$xml = file_get_contents($xmlFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($xml);

$configuration = [
    'Uniqlo-MY' => [
        'MY' => [
            "clientCode" => "UQM",
            "warehouseCode" => "QSMYSA",
            "carrierCode" => "EZY2SHIP",
            "carrierMode" => "WWXEXA",
            "serviceLevel" => "WWXEXA",
            "exchangeRate" => 1,
            "isIncludeShipmentFeeInFreightCost" => 1,
            "isInventoryComparison" => 1,            
            "NEW-LAUNCH-SKUS" => [
                "2000098361753",
                "2000091860222",
                "2000100231128"
            ]
        ],
        'collectco' => [
            'clientCode' => "clientCode-C0",
            'warehouseCode' => "warehouseCode-CO",
            'carrierCode' => "warehouseCode-C0",
            'carrierMode' => "carrierMode-CO",
            'serviceLevel' => "serviceLevel-CO"
        ],
        'clickncollect' => [
            'clientCode' => "clientCode-CnC",
            'warehouseCode' => "warehouseCode-CnC",
            'carrierCode' => "warehouseCode-CnC",
            'carrierMode' => "carrierMode-CnC",
            'serviceLevel' => "serviceLevel-CnC"
        ]
    ]
];

//echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;

$handler = new \Spec\Handler\Uniqlo\MY\OrderSupWms127($payload);
$handler->setProcessConfiguration($configuration);
$handler->execute();

foreach ($handler->getPayloadChild() as $key => $child) {
//    echo "Output {$key}:" . PHP_EOL;
//    echo $child->getContent() . PHP_EOL;

    $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.xml";
    file_put_contents($outputFile, $child->getContent());

    echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
}
