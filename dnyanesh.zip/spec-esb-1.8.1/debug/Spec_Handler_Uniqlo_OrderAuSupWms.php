<?php

/**
 * Debug script to test \Spec\Handler\Wms\OrderSupWms class.
 * This script requires the existence of xml file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Handler_Wms_OrderSupWms.php
 * /debug/Spec_Handler_Wms_OrderSupWms.xml
 * @author Harry Lesmana <harrylesmana@singpost.com>
 * @since 2016-01-27
 */
require_once "bootstrap.php";

$xmlFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$xml = file_get_contents($xmlFile);
$xmlOriginFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "_Origin.xml";

$payload = new \Spec\Model\Payload();
$payload->setContent($xml);

$configuration = [
    'Uniqlo' => [
        'AU' => [
            "clientCode" => "UQO",
            "warehouseCode" => "QSAUSF",
            "carrierCode" => "WWXEXA",
            "carrierMode" => "",
            "serviceLevel" => "",
            "exchangeRate" => 1,
            "originContextId" => 15700,
            "isIncludeShipmentFeeInFreightCost" => 0,
            "isInventoryComparison" => 1,
            "NEW-LAUNCH-SKUS" => [
                "2000058707973",
                "2000091860222",
                "2000100231128"
            ]
        ]
    ]
];

echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;

/* Add dummy record to database */
$data = array(
    "context_id" => "1",
    "external_id" => "200070733",
    "content" => file_get_contents($xmlOriginFile),
    "sys_status_code" => "FIN",
    "sys_created_by" => "0",
    "sys_created_on" => new \Zend_Db_Expr("UTC_TIMESTAMP()")
);
\Spec\App::getDbAdapter()->insert("esb_payload", $data);

$handler = new \Spec\Handler\Uniqlo\OrderAuSupWms($payload);
$handler->setProcessConfiguration($configuration);
$handler->execute();

foreach ($handler->getPayloadChild() as $key => $child) {
    echo "Output {$key}:" . PHP_EOL;
    echo $child->getContent() . PHP_EOL;

    $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.xml";
    file_put_contents($outputFile, $child->getContent());

    echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
}
