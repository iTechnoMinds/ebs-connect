<?php

/**
 * Debug script to test \Spec\Handler\Uniqlo\SG\ShipmentHjHuper class.
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2017-08-29
 */
require_once "bootstrap.php";

$payloadFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$payloadContent = file_get_contents($payloadFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($payloadContent);

$configuration = [
    "supplizerDb" => [
        "dbHost" => "localhost",
        "dbUser" => "",
        "dbPass" => "",
        "dbName" => "",
        "port" => "22"
    ]
];

echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;

$handler = new \Spec\Handler\Uniqlo\SG\ShipmentHjHuper($payload);
$handler->setProcessConfiguration($configuration);
$handler->execute();


foreach ($handler->getPayloadChild() as $key => $child) {
    echo "Output {$key}:" . PHP_EOL;
    echo $child->getContent() . PHP_EOL;

    $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.xml";
    file_put_contents($outputFile, $child->getContent());

    echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
}
