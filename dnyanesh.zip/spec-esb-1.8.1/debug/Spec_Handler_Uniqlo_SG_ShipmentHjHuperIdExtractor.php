<?php

/**
 * Debug script to test Spec\Handler\Uniqlo\SG\ShipmentHjHuperIdExtractor
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2017-10-03
 */
require_once "bootstrap.php";

$payloadFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".json";
$payloadContent = file_get_contents($payloadFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($payloadContent);
$payload->setContentType("application/json");
$payload->setId();

$configuration = [];
echo "Configuration:" . PHP_EOL;
echo"<pre>";print_r($configuration);echo"<br>";
echo PHP_EOL;

try {
    $handler = new Spec\Handler\Uniqlo\SG\ShipmentHjHuperIdExtractor($payload);
    $handler->setProcessConfiguration($configuration);
    $handler->execute();
} catch (\Exception $ex) {
    
} finally {
    foreach ($handler->getExternalId() as $externalId) {
        echo "{$externalId['type']}: {$externalId['external_id']}" . PHP_EOL;
    }
}
