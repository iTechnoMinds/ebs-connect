<?php

/**
 * Debug script to test \Spec\Handler\Uniqlo\TH\OrderMagentoSupplizerEnricher class.
 * This script requires the existence of xml file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Handler_Uniqlo_TH_OrderMagentoSupplizerEnricher.php
 * /debug/Spec_Handler_Uniqlo_TH_OrderMagentoSupplizerEnricher.xml
 * @author Dnyanesh Telgad<dnyaneshwarte@cybage.com>
 * @since 2016-12-14
 */
require_once "bootstrap.php";

$xmlFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$xml = file_get_contents($xmlFile);
$xmlOriginFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "_Origin.xml";

$payload = new \Spec\Model\Payload();
$payload->setContent($xml);

//$configuration = [
//    "validationConfig" => [
//        "cyberSourceFraud" => [
//            "isEnabled" => 1,
//            "paymentMethod" => ["cybersource", "cybersource.general"],
//            "retryDelay" => 15
//        ]
//    ],
//    "cybersource" => [
//        "merchantId" => "spec_uq_th",
//        "apiKeyID" => "97a2d5cc-0f96-4a01-bc50-f88dd192da04",
//        "secretKey" => "YqbzhFB0q3NOsFX7GyoKIYPm8f2W0/1G8Cx2WwcWr70=",
//        "runEnv" => "cyberSource.environment.PRODUCTION",
//        "statusCode" => "SOK"
//    ]
//];

$configuration = [
    "validationConfig" => [
        "cyberSourceFraud" => [
            "isEnabled" => 1,
            "paymentMethod" => ["cybersource", "cybersource.general"],
            "retryDelay" => 15
        ]
    ],
    "cybersource" => [
        "merchantId" => "karuppaiah",
        "apiKeyID" => "4e4ebc5e-5d6e-4fa2-90d0-a179904a5fe5",
        "secretKey" => "Guh71nxdm2STeNKjb+Fl76DZzpgvBxKguoznOTWzwD8=",
        "runEnv" => "cyberSource.environment.SANDBOX",
        "statusCode" => "SOK"
    ]
];


echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;

$handler = new \Spec\Handler\Uniqlo\TH\OrderMagentoSupplizerEnricher($payload);
$handler->setProcessConfiguration($configuration);
$handler->execute();

foreach ($handler->getPayloadChild() as $key => $child) {
//    echo "Output {$key}:" . PHP_EOL;
//    echo $child->getContent() . PHP_EOL;

    $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.xml";
    file_put_contents($outputFile, $child->getContent());

    echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
}
