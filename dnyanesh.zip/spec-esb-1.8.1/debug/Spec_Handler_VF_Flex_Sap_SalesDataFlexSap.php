<?php

/**
 * Debug script to test \Spec\Handler\VF\Flex\Sap\SalesDataFlexSap class.
 * This script requires the existence of csv file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Handler_VF_Flex_Sap_SalesDataFlexSap.php
 * /debug/Spec_Handler_VF_Flex_Sap_SalesDataFlexSap.XML
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2020-07-16
 */
require_once "bootstrap.php";

$xmlFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".json";
$xml = file_get_contents($xmlFile);
$xmlOriginFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "_Origin.json";
$payload = new \Spec\Model\Payload();
$payload->setContent($xml);


$configuration = [
    "originContextId" => "21405",
    "shippingSkuBarCode" => ["sku" => "VN0A5EE9NOA10OS", "barCode" => "192363877433"],   
    "storesMap" => ["HK" => "006091", "SG" => "006092", "MY" => "006093", "PH" => "006094", "ID" => "006095", "TH" => "006096"],
    "tenderCode" => ["wechatpay" => "WE", "wechatpayweb" => "WE", "mc" => "MA", "vi" => "VI", "visa" => "VI", "alipay" => "AL", "unionpay" => "CU", "cup" => "CU", "un" => "CU", "molpay_ebanking_fpx_my" => "BA"]
];

echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;
/* Add dummy record to database */

$data = array(
    "context_id" => "21405",
    "external_id" => "VANSHKCN000001432",
    "content" => file_get_contents($xmlOriginFile),
    "sys_status_code" => "FIN",
    "sys_created_by" => "0",
    "sys_created_on" => new \Zend_Db_Expr("UTC_TIMESTAMP()")
);

//\Spec\App::getDbAdapter()->insert("esb_payload", $data);

$handler = new Spec\Handler\VF\Flex\Sap\SalesDataFlexSap($payload);
$handler->setProcessConfiguration($configuration);
$handler->execute();

foreach ($handler->getPayloadChild() as $key => $child) {
    echo "Output {$key}:" . PHP_EOL;
    echo $child->getContent() . PHP_EOL;

    $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.json";
    file_put_contents($outputFile, $child->getContent());

    echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
}
