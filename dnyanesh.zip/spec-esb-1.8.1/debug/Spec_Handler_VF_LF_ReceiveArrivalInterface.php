<?php

/**
 * Debug script to test Spec\Handler\VF\LF\Flex\ReceiveArrivalInterface class.
 * This script requires the existence of XML file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Handler_VF_LF_ReceiveArrivalInterface.php
 * /debug/Spec_Handler_VF_LF_ReceiveArrivalInterface.XML
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2020-07-29
 */
require_once "bootstrap.php";

$xmlFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$xml = file_get_contents($xmlFile);
$xmlOriginFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "_Origin.json";
$payload = new \Spec\Model\Payload();
$payload->setContent($xml);

$configuration = [
    "RETURN" => "21192",
    "ASN" => "21191"
];

echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;
/* Add dummy record to database */



$handler = new Spec\Handler\VF\LF\ReceiveArrivalInterface($payload);
$handler->setProcessConfiguration($configuration);
$handler->execute();

foreach ($handler->getPayloadChild() as $key => $child) {
    echo "Output {$key}:" . PHP_EOL;
    echo $child->getContent() . PHP_EOL;

    $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.xml";
    file_put_contents($outputFile, $child->getContent());

    echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
}
