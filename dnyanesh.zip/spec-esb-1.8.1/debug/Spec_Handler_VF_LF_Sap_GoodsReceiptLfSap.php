<?php

/**
 * Debug script to test \Spec\Handler\VF\Sap\GoodsReceiptLfSap class.
 * This script requires the existence of XML file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Handler_VF_LF_Sap_GoodsReceiptLfSap.php
 * /debug/Spec_Handler_VF_LF_Sap_GoodsReceiptLfSap.XML
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2020-05-25
 */
require_once "bootstrap.php";

$xmlFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$xml = file_get_contents($xmlFile);
$xmlOriginFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "_Origin.json";
$payload = new \Spec\Model\Payload();
$payload->setContent($xml);

$configuration = [
   "originContextId" => "21180"
];

echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;
/* Add dummy record to database */



$handler = new Spec\Handler\VF\LF\Sap\GoodsReceiptLfSap($payload);
$handler->setProcessConfiguration($configuration);
$handler->execute();

foreach ($handler->getPayloadChild() as $key => $child) {
    echo "Output {$key}:" . PHP_EOL;


    $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.json";
    file_put_contents($outputFile, $child->getContent());

    echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
}
