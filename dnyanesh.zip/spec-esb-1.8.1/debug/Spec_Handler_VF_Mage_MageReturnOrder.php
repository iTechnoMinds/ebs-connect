<?php

/**
 * Debug script to test \Spec\Handler\VF\Mage\MageReturnOrder class.
 * This script requires the existence of csv file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Handler_VF_Mage_MageReturnOrder.php
 * /debug/Spec_Handler_VF_Mage_MageReturnOrder.xml
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2020-06-03
 */
require_once "bootstrap.php";

$csvFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$csv = file_get_contents($csvFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($csv);
$configuration = [
    "user" => "vansuat",
    "password" => "vans@123",
    "url" => "https://vanssgstg.specom.io/rest/V1/",
    "path" => "returns",
    "limit" => "?searchCriteria[filter_groups][0][filters][0][field]=status&searchCriteria[filter_groups][0][filters][0][value]=authorized&searchCriteria[filter_groups][0][filters][0][condition_type]=eq"
];

echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;

$handler = new Spec\Handler\VF\Mage\MageReturnOrder($payload);
$handler->setProcessConfiguration($configuration);
$handler->execute();

foreach ($handler->getPayloadChild() as $key => $child) {
    echo "Output {$key}:" . PHP_EOL;
    echo $child->getContent() . PHP_EOL;

    $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.xml";
    file_put_contents($outputFile, $child->getContent());

    echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
}
