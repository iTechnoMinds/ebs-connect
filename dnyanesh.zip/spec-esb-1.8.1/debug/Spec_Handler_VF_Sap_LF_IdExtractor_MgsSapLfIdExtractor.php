<?php

/**
 * Debug script to test Spec\Handler\VF\LF\Sap\IdExtractor\MgsSapLfIdExtractor class.
 * This script requires the existence of csv file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Handler_VF_Sap_LF_IdExtractor_MgsSapLfIdExtractor.php
 * /debug/Spec_Handler_VF_Sap_LF_IdExtractor_MgsSapLfIdExtractor.json
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2020-8-04
 */
require_once "bootstrap.php";

$jsonFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".json";
$json = file_get_contents($jsonFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($json);
$payload->setId(480700);
//21411/21180/21200/
//21180"idType" => "sap-lf-asn-id",
//21200"idType" => "sap-lf-transfer-id",
$configuration = [
    "idType" => "sap-lf-message-id"
];

echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;

$handler = new Spec\Handler\VF\Sap\LF\IdExtractor\MgsSapLfIdExtractor($payload);
$handler->setProcessConfiguration($configuration);
$handler->execute();

foreach ($handler->getPayloadChild() as $key => $child) {
    echo "Output {$key}:" . PHP_EOL;
    echo $child->getContent() . PHP_EOL;

    $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.xml";
    file_put_contents($outputFile, $child->getContent());

    echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
}
