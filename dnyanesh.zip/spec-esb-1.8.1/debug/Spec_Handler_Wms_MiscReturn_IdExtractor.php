<?php

/**
 * Debug script to test \Spec\Handler\Wms\MiscReturn\IdExtractor class.
 * This script requires the existence of xml file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Handler_Wms_MiscReturn_IdExtractor.php
 * /debug/Spec_Handler_Wms_MiscReturn_IdExtractor.xml
 * @author Harry Lesmana <harrylesmana@singpost.com>
 * @since 2016-12-23
 */
require_once "bootstrap.php";

$xmlFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$xml = file_get_contents($xmlFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($xml);
$payload->setId(5);

$configuration = [
    "isNormalOrderNumber" => TRUE
];

echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;

try {
    $handler = new \Spec\Handler\Wms\MiscReturn\IdExtractor($payload);
    $handler->setProcessConfiguration($configuration);
    $handler->execute();
} catch (\Exception $ex) {
    
} finally {
    foreach ($handler->getExternalId() as $externalId) {
        echo "{$externalId['type']}: {$externalId['external_id']}" . PHP_EOL;
    }
}

