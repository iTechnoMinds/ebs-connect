<?php

/**
 * Debug script to test \Spec\Handler\Wms\OrderSupWms class.
 * This script requires the existence of xml file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Handler_Wms_OrderSupWms.php
 * /debug/Spec_Handler_Wms_OrderSupWms.xml
 * @author Harry Lesmana <harrylesmana@singpost.com>
 * @since 2016-01-27
 */
require_once "bootstrap.php";

$xmlFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$xml = file_get_contents($xmlFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($xml);

$configuration = [
    'UnderArmour' => [
        'SG' => [
            'clientCode' => "UAS",
            'warehouseCode' => "QSSGDF",
            'carrierCode' => "EZY2SHIP",
            'carrierMode' => "IWCNDD",
            'serviceLevel' => "IWCNDD",
            'exchangeRate' => 1
        ],
        'PH' => [
            'clientCode' => "UAS",
            'warehouseCode' => "QSSGDF",
            'carrierCode' => "EZY2SHIP",
            'carrierMode' => "SPXEXA",
            'serviceLevel' => "SPXEXA",
            'exchangeRate' => 0.029
        ],
        'MY' => [
            'clientCode' => "UAS",
            'warehouseCode' => "QSSGDF",
            'carrierCode' => "EZY2SHIP",
            'carrierMode' => "SPXEXA",
            'serviceLevel' => "SPXEXA",
            'exchangeRate' => 0.421256516165
        ],
        'TH' => [
            'clientCode' => "UAS",
            'warehouseCode' => "QSSGDF",
            'carrierCode' => "EZY2SHIP",
            'carrierMode' => "SPXEXA",
            'serviceLevel' => "SPXEXA",
            'exchangeRate' => 0.04058
        ],
        'ID' => [
            'clientCode' => "UAS",
            'warehouseCode' => "QSSGDF",
            'carrierCode' => "EZY2SHIP",
            'carrierMode' => "SPXEXA",
            'serviceLevel' => "SPXEXA",
            'exchangeRate' => 0.00011
        ]
    ],
    'Uniqlo-SG' => [
        'SG' => [
            'clientCode' => "UQS",
            'warehouseCode' => "QSSGDF",
            'carrierCode' => "EZY2SHIP",
            'carrierMode' => "IWCNDD",
            'serviceLevel' => "IWCNDD",
            'exchangeRate' => 1
        ]
    ],
    'Uniqlo-MY' => [
        'MY' => [
            'clientCode' => 'UQM',
            'warehouseCode' => 'QSMYSA',
            'carrierCode' => 'EZY2SHIP',
            'carrierMode' => 'WWXEXA',
            'serviceLevel' => 'WWXEXA',
            'exchangeRate' => 1,
            'isIncludeShipmentFeeInFreightCost' => 0
        ]
    ],
    'Uniqlo' => [
        'AU' => [
            'clientCode' => 'UQO',
            'warehouseCode' => 'QSAUSF',
            'carrierCode' => 'WWXEXA',
            'carrierMode' => '',
            'serviceLevel' => '',
            'exchangeRate' => 1,
            'originContextId' => 15700,
            'isIncludeShipmentFeeInFreightCost' => 0
        ]
    ]
];

echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;

$handler = new \Spec\Handler\Wms\OrderSupWms($payload);
$handler->setProcessConfiguration($configuration);
$handler->execute();

foreach ($handler->getPayloadChild() as $key => $child) {
    echo "Output {$key}:" . PHP_EOL;
    echo $child->getContent() . PHP_EOL;

    $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.xml";
    file_put_contents($outputFile, $child->getContent());

    echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
}
