<?php

/**
 * Debug script to test \Spec\Handler\Wms\OrderSupWms\IdExtractor117 class.
 * This script requires the existence of xml file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Handler_Wms_OrderSupWms_IdExtractor117.php
 * /debug/Spec_Handler_Wms_OrderSupWms_IdExtractor117.xml
 * @author Harry Lesmana <harrylesmana@singpost.com>
 * @since 2017-02-15
 */
require_once "bootstrap.php";

$xmlFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$xml = file_get_contents($xmlFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($xml);

$configurationString = <<<CONFIG
{"isNormalOrderNumber":false}
CONFIG;

$configuration = json_decode($configurationString);

echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;

try {
    $handler = new \Spec\Handler\Wms\OrderSupWms\IdExtractor117($payload);
    $handler->setProcessConfiguration($configuration);
    $handler->execute();
} catch (\Exception $ex) {
    
} finally {
    foreach ($handler->getExternalId() as $externalId) {
        echo "{$externalId['type']}: {$externalId['external_id']}" . PHP_EOL;
    }
}

