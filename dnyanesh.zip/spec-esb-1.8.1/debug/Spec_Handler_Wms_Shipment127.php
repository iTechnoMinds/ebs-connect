<?php

/**
 * Debug script to test \Spec\Handler\Wms\Shipment127 class.
 * This script requires the existence of xml file with the same name of the script name present in the same folder.
 * Example:
 * /debug/Spec_Handler_Wms_Shipment127.php
 * /debug/Spec_Handler_Wms_Shipment127.xml
 * @author Harry Lesmana <harrylesmana@singpost.com>
 * @author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
 * @since 2015-11-13
 */
require_once "bootstrap.php";

$xmlFile = __DIR__ . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . ".xml";
$xml = file_get_contents($xmlFile);

$payload = new \Spec\Model\Payload();
$payload->setContent($xml);

$configuration = [
    "config" => [
        "isShipmentByLineId" => [
            "HCK" => TRUE,
            "HCL" => TRUE,
            "SCL" => TRUE,
            "MCL" => TRUE,
            "ACL" => TRUE
        ],
        "trackingNumberKeywordReject" => [
            "HCL" => [
                "EZY",
                " ",
                "TRAK"
            ]
        ],
        "trackingNumberSpecialReject" => [
            "HCL" => [
                "duplicateSku" => FALSE,
                "orderNumber" => FALSE,
                "duplicateLineId" => FALSE
            ]
        ],
        "UQT" => [
            "isOverrideTrackingClientCodeOrderNumber" => TRUE
        ],
        "isForceFullShipment" => FALSE
    ]
];

echo "Configuration:" . PHP_EOL;
echo json_encode($configuration) . PHP_EOL;

$handler = new \Spec\Handler\Wms\Shipment127($payload);
$handler->setProcessConfiguration($configuration);
$handler->execute();

foreach ($handler->getPayloadChild() as $key => $child) {
    echo "Output {$key}:" . PHP_EOL;
    echo $child->getContent() . PHP_EOL;

    $outputFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . pathinfo(__FILE__, PATHINFO_FILENAME) . "-OUTPUT-{$key}.xml";
    file_put_contents($outputFile, $child->getContent());

    echo "Written to {$outputFile}" . PHP_EOL . PHP_EOL;
}
