<?php

/**
 * All debug files, need to include this bootstrap to ensure the necessary resources are setup.
 */
date_default_timezone_set("UTC");
error_reporting(E_ALL ^ E_WARNING);

define("ROOT_PATH", realpath(__DIR__ . DIRECTORY_SEPARATOR . ".." . DIRECTORY_SEPARATOR));

/* Require vendor autoload  */
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "vendor" . DIRECTORY_SEPARATOR . "autoload.php";
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "application" . DIRECTORY_SEPARATOR . "bootstrap.php";

