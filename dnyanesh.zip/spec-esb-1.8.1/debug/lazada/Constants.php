<?php

namespace Lazada;

class Constants
{
	static $log_level_debug = "DEBUG";
	static $log_level_info = "INFO";
	static $log_level_error = "ERROR";
}
