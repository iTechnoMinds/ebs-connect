ALTER TABLE `dem_order_header`
	ALTER `amount` DROP DEFAULT;
ALTER TABLE `dem_order_header`
	CHANGE COLUMN `amount` `amount` DECIMAL(10,2) NOT NULL AFTER `payment_method_name`,
	CHANGE COLUMN `merc_net_price` `merc_net_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `processor_id`,
	CHANGE COLUMN `merc_tax` `merc_tax` DECIMAL(10,2) NULL DEFAULT NULL AFTER `merc_net_price`,
	CHANGE COLUMN `merc_gross_price` `merc_gross_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `merc_tax`,
	CHANGE COLUMN `adj_merc_net_price` `adj_merc_net_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `merc_gross_price`,
	CHANGE COLUMN `adj_merc_tax` `adj_merc_tax` DECIMAL(10,2) NULL DEFAULT NULL AFTER `adj_merc_net_price`,
	CHANGE COLUMN `adj_merc_gross_price` `adj_merc_gross_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `adj_merc_tax`,
	CHANGE COLUMN `shiping_net_price` `shiping_net_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `adj_merc_gross_price`,
	CHANGE COLUMN `shiping_tax` `shiping_tax` DECIMAL(10,2) NULL DEFAULT NULL AFTER `shiping_net_price`,
	CHANGE COLUMN `shiping_gross_price` `shiping_gross_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `shiping_tax`,
	CHANGE COLUMN `adj_shiping_net_price` `adj_shiping_net_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `shiping_gross_price`,
	CHANGE COLUMN `adj_shiping_tax` `adj_shiping_tax` DECIMAL(10,2) NULL DEFAULT NULL AFTER `adj_shiping_net_price`,
	CHANGE COLUMN `adj_shiping_gross_price` `adj_shiping_gross_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `adj_shiping_tax`,
	CHANGE COLUMN `order_net_price` `order_net_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `adj_shiping_gross_price`,
	CHANGE COLUMN `order_tax` `order_tax` DECIMAL(10,2) NULL DEFAULT NULL AFTER `order_net_price`,
	CHANGE COLUMN `order_gross_price` `order_gross_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `order_tax`;


CREATE TABLE `dem_order_payments` (
	`id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`order_header_id` INT(10) NOT NULL,
	`amount` DECIMAL(10,2) NOT NULL,
	`processor_id` VARCHAR(150) NOT NULL COLLATE 'utf8_unicode_ci',
	`transaction_id` VARCHAR(150) NOT NULL COLLATE 'utf8_unicode_ci',
	`method_name` VARCHAR(150) NOT NULL COLLATE 'utf8_unicode_ci',
	`modified_by` INT(11) NOT NULL,
	`modified_on` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	`created_by` INT(11) NOT NULL,
	`created_on` TIMESTAMP NOT NULL DEFAULT '0000-00-00 00:00:00',
	PRIMARY KEY (`id`)
)
COMMENT='Storing order payment details.'
COLLATE='utf8_unicode_ci'
ENGINE=InnoDB;


ALTER TABLE `dem_product_item_line`
	CHANGE COLUMN `net_price` `net_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `product_id`,
	CHANGE COLUMN `tax` `tax` DECIMAL(10,2) NULL DEFAULT NULL AFTER `net_price`,
	CHANGE COLUMN `gross_price` `gross_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `tax`,
	CHANGE COLUMN `base_price` `base_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `gross_price`,
	CHANGE COLUMN `tax_basis` `tax_basis` DECIMAL(10,2) NULL DEFAULT NULL AFTER `line_item_text`,
	CHANGE COLUMN `quantity` `quantity` DECIMAL(10,2) NULL DEFAULT NULL AFTER `product_name`,
	CHANGE COLUMN `tax_rate` `tax_rate` DECIMAL(10,2) NULL DEFAULT NULL AFTER `quantity`;
	
ALTER TABLE `dem_shipment`
	CHANGE COLUMN `merc_net_price` `merc_net_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `gift`,
	CHANGE COLUMN `merc_tax` `merc_tax` DECIMAL(10,2) NULL DEFAULT NULL AFTER `merc_net_price`,
	CHANGE COLUMN `merc_gross_price` `merc_gross_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `merc_tax`,
	CHANGE COLUMN `adj_merc_net_price` `adj_merc_net_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `merc_gross_price`,
	CHANGE COLUMN `adj_merc_tax` `adj_merc_tax` DECIMAL(10,2) NULL DEFAULT NULL AFTER `adj_merc_net_price`,
	CHANGE COLUMN `adj_merc_gross_price` `adj_merc_gross_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `adj_merc_tax`,
	CHANGE COLUMN `shiping_net_price` `shiping_net_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `adj_merc_gross_price`,
	CHANGE COLUMN `shiping_tax` `shiping_tax` DECIMAL(10,2) NULL DEFAULT NULL AFTER `shiping_net_price`,
	CHANGE COLUMN `shiping_gross_price` `shiping_gross_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `shiping_tax`,
	CHANGE COLUMN `adj_shiping_net_price` `adj_shiping_net_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `shiping_gross_price`,
	CHANGE COLUMN `adj_shiping_tax` `adj_shiping_tax` DECIMAL(10,2) NULL DEFAULT NULL AFTER `adj_shiping_net_price`,
	CHANGE COLUMN `adj_shiping_gross_price` `adj_shiping_gross_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `adj_shiping_tax`,
	CHANGE COLUMN `shipment_net_price` `shipment_net_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `adj_shiping_gross_price`,
	CHANGE COLUMN `shipment_tax` `shipment_tax` DECIMAL(10,2) NULL DEFAULT NULL AFTER `shipment_net_price`,
	CHANGE COLUMN `shipment_gross_price` `shipment_gross_price` DECIMAL(10,2) NULL DEFAULT NULL AFTER `shipment_tax`;
	
ALTER TABLE `dem_shipping_item_line`
	CHANGE COLUMN `net_price` `net_price` DECIMAL(10,2) UNSIGNED NULL DEFAULT NULL AFTER `shipment_id`,
	CHANGE COLUMN `tax` `tax` DECIMAL(10,2) UNSIGNED NULL DEFAULT NULL AFTER `net_price`,
	CHANGE COLUMN `gross_price` `gross_price` DECIMAL(10,2) UNSIGNED NULL DEFAULT NULL AFTER `tax`,
	CHANGE COLUMN `base_price` `base_price` DECIMAL(10,2) UNSIGNED NULL DEFAULT NULL AFTER `gross_price`,
	CHANGE COLUMN `tax_basis` `tax_basis` DECIMAL(10,2) UNSIGNED NULL DEFAULT NULL AFTER `line_item_text`,
	CHANGE COLUMN `tax_rate` `tax_rate` DECIMAL(10,2) UNSIGNED NULL DEFAULT NULL AFTER `item_id`;
	
ALTER TABLE dem_custom_attribute CHARACTER SET utf8;
ALTER TABLE dem_note CHARACTER SET utf8;
ALTER TABLE dem_order_header CHARACTER SET utf8;
ALTER TABLE dem_shipment CHARACTER SET utf8;
ALTER TABLE dem_shipping_item_line CHARACTER SET utf8;
ALTER TABLE dev_product_item_line CHARACTER SET utf8;