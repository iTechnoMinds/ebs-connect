ALTER TABLE `esb_payload_outbound`
	ADD COLUMN `last_execution_time` FLOAT NOT NULL DEFAULT '0.00' AFTER `last_response_body`
;
