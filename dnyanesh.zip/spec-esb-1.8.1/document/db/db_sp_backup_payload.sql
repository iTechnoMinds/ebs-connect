/*
Event excecuting SP on define time.
Stored procedure for taking daily backup of esb_payload,esb_payload_event,esb_payload_outbound into backup_esb_payload,backup_esb_payload_event,backup_esb_payload_outbound respectively
Fetch criteria:
- no of records remain as parameter. for ex. 4862 and you pass 4000 then 862 record get process.
@author Dnyaneshwar Telgad <dnyaneshwarte@cybage.com>
@since 2015-10-22
@updated 2016-04-22
*/
-- Dumping structure for event midz_backup.archive_payload

DELIMITER //
SET GLOBAL event_scheduler = ON;
CREATE  EVENT `archive_payload` ON SCHEDULE EVERY 1 MINUTE STARTS '2016-04-22 03:01:46' ON COMPLETION NOT PRESERVE DISABLE DO CALL `sp_backup_payload`('10000')//
DELIMITER ;


-- Dumping structure for procedure midz_backup.sp_backup_payload
DELIMITER //

CREATE PROCEDURE `sp_backup_payload`(IN `max_records` INT)
BEGIN 
	 SELECT count(id) INTO @payload_total FROM esb_payload;
	 SET @max_records = max_records;	 
	 SET @to_id = ( @payload_total - @max_records );	 
	 
	 PREPARE stmt FROM "SELECT MAX(id) into @maxid FROM ( SELECT id FROM esb_payload ORDER BY id ASC LIMIT ? ) as temp;";
	 EXECUTE stmt USING @to_id;
    DEALLOCATE PREPARE stmt;   
    
	 IF @payload_total > @max_records THEN	  
	     
	      -- Dumping structure for table backup_esb_payload if not exists
	   CREATE TABLE IF NOT EXISTS `backup_esb_payload` (
				`id` BIGINT(20) UNSIGNED NOT NULL,
				`context_id` BIGINT(20) UNSIGNED NOT NULL,
				`parent_id` BIGINT(20) UNSIGNED NULL DEFAULT NULL COMMENT 'Reference to parent payload if any',
				`external_id` VARCHAR(50) NULL DEFAULT NULL COMMENT 'External ID as extracted from the payload' COLLATE 'utf8_unicode_ci',
				`content` LONGTEXT NOT NULL COMMENT 'Actual payload content' COLLATE 'utf8_unicode_ci',
				`content_s3_bucket` VARCHAR(50) NULL DEFAULT NULL COMMENT 'S3 bucket of the payload' COLLATE 'utf8_unicode_ci',
				`content_s3_key` VARCHAR(250) NULL DEFAULT NULL COMMENT 'S3 key of the payload' COLLATE 'utf8_unicode_ci',
				`header` TEXT NOT NULL COMMENT 'Header of the payload (if any)' COLLATE 'utf8_unicode_ci',
				`ip_address` VARCHAR(50) NULL DEFAULT NULL COMMENT 'IP address from which payload is originated' COLLATE 'utf8_unicode_ci',
				`sys_status_code` CHAR(5) NOT NULL DEFAULT 'NEW' COLLATE 'utf8_unicode_ci',
				`sys_created_by` INT(10) UNSIGNED NOT NULL,
				`sys_created_on` DATETIME NOT NULL,
				`sys_modified_by` INT(10) UNSIGNED NULL DEFAULT NULL,
				`sys_modified_on` TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
				`uuid_flag` CHAR(36) NULL DEFAULT NULL COLLATE 'utf8_unicode_ci',
				PRIMARY KEY (`id`),
				INDEX `status_code` (`sys_status_code`),
				INDEX `created_on` (`sys_created_on`),
				INDEX `modified_on` (`sys_modified_on`),
				INDEX `FK_esb_payload_esb_context` (`context_id`),
				INDEX `FK_esb_payload_esb_payload` (`parent_id`),
				INDEX `external_id` (`external_id`),
				INDEX `uuid_flag` (`uuid_flag`)
			)
			COLLATE='utf8_unicode_ci'
			ENGINE=InnoDB
			ROW_FORMAT=COMPACT;
			
			-- Dumping structure for table backup_esb_payload_event if not exists
			CREATE TABLE IF NOT EXISTS `backup_esb_payload_event` (
				`id` BIGINT(20) UNSIGNED NOT NULL,
				`payload_id` BIGINT(20) UNSIGNED NOT NULL COMMENT 'Reference to `payload.id`',
				`context_process_id` BIGINT(20) UNSIGNED NULL DEFAULT NULL COMMENT 'Reference to `esb_context_process.id`',
				`context_type` ENUM('PROCESS','OUTBOUND') NOT NULL DEFAULT 'PROCESS' COLLATE 'utf8_unicode_ci',
				`description` TEXT NULL COLLATE 'utf8_unicode_ci',
				`sys_status_code` CHAR(5) NOT NULL COLLATE 'utf8_unicode_ci',
				`sys_created_by` INT(10) UNSIGNED NOT NULL,
				`sys_created_on` DATETIME NOT NULL,
				`sys_modified_by` INT(10) UNSIGNED NULL DEFAULT NULL,
				`sys_modified_on` TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
				PRIMARY KEY (`id`),
				INDEX `payload_id` (`payload_id`),
				INDEX `context_process_id` (`context_process_id`),
				INDEX `context_outbound_id` (`context_type`)
			)
			COLLATE='utf8_unicode_ci'
			ENGINE=MyISAM
			ROW_FORMAT=COMPACT;
			
			-- Dumping structure for table backup_esb_payload_outbound if not exists
			CREATE TABLE IF NOT EXISTS `backup_esb_payload_outbound` (
				`id` BIGINT(20) UNSIGNED NOT NULL,
				`payload_id` BIGINT(20) UNSIGNED NOT NULL COMMENT 'Payload ID',
				`outbound_id` BIGINT(20) UNSIGNED NOT NULL COMMENT 'Outbound ID',
				`to_process_on` DATETIME NULL DEFAULT NULL COMMENT 'Indicate when to process',
				`transmission_attempted` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Number of transmission has been attempted',
				`transmission_retry_left` INT(10) UNSIGNED NOT NULL DEFAULT '5',
				`last_response_body` TEXT NULL COLLATE 'utf8_unicode_ci',
				`sys_status_code` CHAR(5) NOT NULL COLLATE 'utf8_unicode_ci',
				`sys_created_by` INT(10) UNSIGNED NOT NULL,
				`sys_created_on` DATETIME NOT NULL,
				`sys_modified_by` INT(10) UNSIGNED NULL DEFAULT NULL,
				`sys_modified_on` TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
				`uuid_flag` CHAR(36) NULL DEFAULT NULL COLLATE 'utf8_unicode_ci',
				PRIMARY KEY (`id`),
				UNIQUE INDEX `payload_id_outbound_id` (`payload_id`, `outbound_id`),
				INDEX `FK_esb_payload_outbound_esb_context_outbound` (`outbound_id`),
				INDEX `FK_esb_payload_outbound_app_master_status` (`sys_status_code`),
				INDEX `to_process_on` (`to_process_on`),
				INDEX `transmission_retry_left` (`transmission_retry_left`),
				INDEX `uuid_flag` (`uuid_flag`)
			)
			COLLATE='utf8_unicode_ci'
			ENGINE=InnoDB
			ROW_FORMAT=DYNAMIC;
			
			-- Dumping structure for table event_logs if not exists
			CREATE TABLE IF NOT EXISTS `event_logs` (
				`id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				`event_name` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8_unicode_ci',
				`sys_created_on` TIMESTAMP NULL DEFAULT NULL,
				`sys_modified_on` TIMESTAMP NULL DEFAULT NULL,
				PRIMARY KEY (`id`)
			)
			COMMENT='Storing event execution logs details'
			COLLATE='utf8_unicode_ci'
			ENGINE=MyISAM;


	  	 INSERT INTO backup_esb_payload( SELECT * FROM esb_payload where id <= @maxid );
	     INSERT INTO backup_esb_payload_event( SELECT * FROM esb_payload_event where esb_payload_event.payload_id <= @maxid );
	     INSERT INTO backup_esb_payload_outbound( SELECT * FROM esb_payload_outbound where esb_payload_outbound.payload_id <= @maxid );
	     INSERT INTO event_logs( event_name,sys_created_on )VALUES('archive_payload', UTC_TIMESTAMP() );
	   
	   SET foreign_key_checks = 0;
	     DELETE FROM esb_payload where id <= @maxid ;	
		 DELETE FROM esb_payload_event where esb_payload_event.payload_id <= @maxid ;	
         DELETE FROM esb_payload_outbound where esb_payload_outbound.payload_id <= @maxid ;	  
	   SET foreign_key_checks = 1;
	   
	 END IF; 
END//
DELIMITER ;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
