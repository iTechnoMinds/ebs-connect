ALTER TABLE `esb_payload`
	ADD COLUMN `uuid_flag` CHAR(36) NULL AFTER `sys_modified_on`;
ALTER TABLE `esb_payload_outbound`
	ADD COLUMN `uuid_flag` CHAR(36) NULL AFTER `sys_modified_on`;
ALTER TABLE `esb_payload`
	ADD INDEX `uuid_flag` (`uuid_flag`);
ALTER TABLE `esb_payload_outbound`
	ADD INDEX `uuid_flag` (`uuid_flag`);