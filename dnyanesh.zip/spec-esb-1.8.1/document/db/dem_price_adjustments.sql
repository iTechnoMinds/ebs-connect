CREATE TABLE `dem_price_adjustments` (
	`id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`table_name` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8_unicode_ci',
	`resp_table_record_id` INT(11) NULL DEFAULT NULL,
	`net_price` VARCHAR(20) NULL DEFAULT NULL COLLATE 'utf8_unicode_ci',
	`tax` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8_unicode_ci',
	`gross_price` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8_unicode_ci',
	`base_price` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8_unicode_ci',
	`lineitem_text` VARCHAR(150) NULL DEFAULT NULL COLLATE 'utf8_unicode_ci',
	`tax-basis` DECIMAL(10,0) UNSIGNED NULL DEFAULT NULL,
	`promotion_id` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8_unicode_ci',
	`campaign_id` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8_unicode_ci',
	`coupon_id` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8_unicode_ci',
	`modified_by` INT(11) NOT NULL,
	`modified_on` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	`created_by` INT(11) NOT NULL,
	`created_on` TIMESTAMP NOT NULL DEFAULT '0000-00-00 00:00:00',
	PRIMARY KEY (`id`),
	INDEX `table_name` (`table_name`),
	INDEX `resp_table_record_id` (`resp_table_record_id`)
)
COMMENT='storing the merchandize total price adjustments details'
COLLATE='utf8_unicode_ci'
ENGINE=InnoDB
AUTO_INCREMENT=14;