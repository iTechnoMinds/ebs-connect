<?php

/**
 * Entry point to invoke class which extends from Spec\Bg\BgAbstract.
 * Parameters:
 * - className (MANDATORY) Background class name to be invoked.
 * - jobMaxCycle (OPTIONAL) Number of cycle to run for this background process. If value is not provided or 0, default is infinite.
 * - jobDelay (OPTIONAL) Number of seconds to delay between run if there is no new job found. If valus is not provided, default is 0.
 */
define("ROOT_PATH", realpath(__DIR__ . DIRECTORY_SEPARATOR . ".." . DIRECTORY_SEPARATOR));

/* Require vendor autoload  */
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "vendor" . DIRECTORY_SEPARATOR . "autoload.php";
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "application" . DIRECTORY_SEPARATOR . "bootstrap.php";

/* Extract named parameters */
$params = array();
for ($i = 1; $i < $argc; $i++) {
    list($key, $val) = explode("=", $argv[$i]);
    $params[$key] = $val;
}

$paramClassName = $params["className"];
$paramJobMaxCycle = isset($params["jobMaxCycle"]) ? $params["jobMaxCycle"] : 0;
$paramJobDelay = isset($params["jobDelay"]) ? $params["jobDelay"] : 0;

/* Clear these parameters first before using it as Argument to the Background Job */
unset($params["className"], $params["jobMaxCycle"], $params["jobDelay"]);
try {
    $bgProcess = new $paramClassName($params);
    $bgProcess->setDelayNoJobSecond($paramJobDelay);
    $bgProcess->setMaxCycle($paramJobMaxCycle);
    $bgProcess->run();
} catch (\Exception $ex) {
    echo PHP_EOL . PHP_EOL;
    echo "PROBLEM ENCOUNTERED:" . PHP_EOL . $ex->getMessage() . PHP_EOL . $ex->getTraceAsString() . PHP_EOL;
}
