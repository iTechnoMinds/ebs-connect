<?php

/**
 * Entry point to upload file to S3 and generate SQS message.
 * Parameters:
 * - `headerFile`
 * - `bodyFile`
 */
define("ROOT_PATH", realpath(__DIR__ . DIRECTORY_SEPARATOR . ".." . DIRECTORY_SEPARATOR));

/* Require vendor autoload  */
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "vendor" . DIRECTORY_SEPARATOR . "autoload.php";
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "application" . DIRECTORY_SEPARATOR . "bootstrap.php";

/* Extract named parameters */
$params = array();
for ($i = 1; $i < $argc; $i++) {
    list($key, $val) = explode("=", $argv[$i]);
    $params[$key] = $val;
}

if (!isset($params["headerFile"]) || strlen($params["headerFile"]) == 0) {
    throw \Spec\App::createException("Invalid `headerFile`");
}
if (!isset($params["bodyFile"]) || strlen($params["bodyFile"]) == 0) {
    throw \Spec\App::createException("Invalid `bodyFile`");
}

$handler = new \Spec\Queue\InboundLocal();
$handler->process($params["headerFile"], $params["bodyFile"]);
