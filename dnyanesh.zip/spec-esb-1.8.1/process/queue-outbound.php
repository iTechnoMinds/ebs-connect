<?php

/**
 * Entry point to invoke outbound background process.
 */
define("ROOT_PATH", realpath(__DIR__ . DIRECTORY_SEPARATOR . ".." . DIRECTORY_SEPARATOR));

/* Require vendor autoload  */
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "vendor" . DIRECTORY_SEPARATOR . "autoload.php";
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "application" . DIRECTORY_SEPARATOR . "bootstrap.php";

/* Extract named parameters */
$params = array();
for ($i = 1; $i < $argc; $i++) {
    list($key, $val) = explode("=", $argv[$i]);
    $params[$key] = $val;
}

$process = new \Spec\Bg\Outbound($params);
$process->setDelayNoJobSecond(5);
$process->run();
