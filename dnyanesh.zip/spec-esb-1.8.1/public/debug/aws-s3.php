<?php

define("ROOT_PATH", realpath(__DIR__ . DIRECTORY_SEPARATOR . ".." . DIRECTORY_SEPARATOR . ".." . DIRECTORY_SEPARATOR));

/* Require vendor autoload  */
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "vendor" . DIRECTORY_SEPARATOR . "autoload.php";
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "application" . DIRECTORY_SEPARATOR . "bootstrap.php";

$bucket = \Spec\App::getConfig()->aws->s3->inbound->bucket;
$key = "debug-test-76e8a6d2-e174-4a71-8b72-7d4ac4b5b1cb.txt";
$data = "Hello!";

try {
    $s3Client = \Spec\App::getAwsS3();
    echo "Put result:\n";
    var_dump(\Spec\Wrap\S3::putObject($s3Client, $bucket, $key, $data));
    echo "Get result:\n";
    var_dump(\Spec\Wrap\S3::getObject($s3Client, $bucket, $key));
} catch (Exception $ex) {
    echo "Exception encountered:\n";
    echo $ex->getMessage() . "\n";
    echo $ex->getTraceAsString() . "\n";
}

