<?php

define("ROOT_PATH", realpath(__DIR__ . DIRECTORY_SEPARATOR . ".." . DIRECTORY_SEPARATOR . ".." . DIRECTORY_SEPARATOR));

/* Require vendor autoload  */
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "vendor" . DIRECTORY_SEPARATOR . "autoload.php";
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "application" . DIRECTORY_SEPARATOR . "bootstrap.php";

$queueUrl = \Spec\App::getAwsSqsQueueUrl("inbound");

$client = \Spec\App::getAwsSqs();
$queueMessage = new \Spec\Model\Sqs();
$queueMessage->setQueueUrl($queueUrl);
$queueMessage->setMessageBody("Hello SQS world!");
$queueMessage->addMessageAttributeString("attribute01", "Value of attribute 01");
$queueMessage->addMessageAttributeString("attribute02", "Value of attribute 02");

var_dump("-- DATA --", $queueMessage->getMessagePush());
var_dump("-- SEND RESULT --", $result = \Spec\Wrap\Sqs::sendMessage($client, $queueMessage));

$sqsMessage = \Spec\Wrap\Sqs::receiveMessage($client, $queueMessage);
$sqsModels = \Spec\Model\Sqs::createFromMessage($sqsMessage, $queueUrl);
foreach ($sqsModels as $sqsModel) {
    var_dump("-- RECEIVE --", $sqsModel);
    var_dump("-- DELETE RESULT --", \Spec\Wrap\Sqs::deleteMessage($client, $sqsModel));
}