<?php

define("ROOT_PATH", realpath(__DIR__ . DIRECTORY_SEPARATOR . ".." . DIRECTORY_SEPARATOR . ".." . DIRECTORY_SEPARATOR));

/* Require vendor autoload  */
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "vendor" . DIRECTORY_SEPARATOR . "autoload.php";
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "application" . DIRECTORY_SEPARATOR . "bootstrap.php";

$config = new \Spec\Model\EndpointConfig();
$config->setHost("127.0.0.1")->setPath("core")->setPort(80)->setMaxRetry(5);
$payload = new \Spec\Model\Payload();
$payload->setContent("<test>Endpoint-HTTP/S</test>")
        ->setContentType("text/html")
        ->addHeader("contextCode", "test-abc")
        ->addHeader("authUser", "test-user")
        ->addHeader("authKey", "test-key")
;
$endpoint = new \Spec\Endpoint\Http($config);
$endpoint->put($payload);
