<?php

define("ROOT_PATH", realpath(__DIR__ . DIRECTORY_SEPARATOR . ".." . DIRECTORY_SEPARATOR . ".." . DIRECTORY_SEPARATOR));

/* Require vendor autoload  */
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "vendor" . DIRECTORY_SEPARATOR . "autoload.php";
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "application" . DIRECTORY_SEPARATOR . "bootstrap.php";

$xml = <<<XML
<?xml version="1.0" encoding="utf-8"?>					
<ShipConfirmation>					
	<ConfirmationHeader>				
		<OrderID>O123</OrderID>			
		<MerchantID>M123</MerchantID>			
		<WarehouseID>QSSGDF</WarehouseID>			
	</ConfirmationHeader>				
	<ConfirmationDetail>				
		<ShipmentDetail>			
			<ShipmentLine>		
				<LineNumber>1</LineNumber>	
				<ShipDate>09/11/2014 09:00:00</ShipDate>	
				<TrackingNumber>T234</TrackingNumber>	
				<TotalWeight>10.01</TotalWeight>	
				<TotalVolume>100.11</TotalVolume>	
			</ShipmentLine>		
			<ShipmentLine>		
				<LineNumber>2</LineNumber>	
				<ShipDate>09/11/2014 09:00:00</ShipDate>	
				<TrackingNumber>T345</TrackingNumber>	
				<TotalWeight>10.01</TotalWeight>	
				<TotalVolume>100.11</TotalVolume>	
			</ShipmentLine>		
		</ShipmentDetail>			
		<ItemDetail>			
			<ItemLine>		
				<LineNumber>1</LineNumber>	
				<SKU>ABC1</SKU>	
				<LotNumber>L123</LotNumber>	
				<QuantityShipped>1</QuantityShipped>	
				<InventoryStatus>OK</InventoryStatus>	
				<ExpiryDate>09/11/2014 09:00:00</ExpiryDate>	
				<SerialDetail>	
					<SerialNumber>Z123</SerialNumber>
				</SerialDetail>	
			</ItemLine>		
			<ItemLine>		
				<LineNumber>2</LineNumber>	
				<SKU>DEF1</SKU>	
				<LotNumber>L123</LotNumber>	
				<QuantityShipped>1</QuantityShipped>	
				<InventoryStatus>OK</InventoryStatus>	
				<ExpiryDate>09/11/2014 09:00:00</ExpiryDate>	
				<SerialDetail>	
					<SerialNumber>Z234</SerialNumber>
				</SerialDetail>	
			</ItemLine>		
		</ItemDetail>			
	</ConfirmationDetail>				
</ShipConfirmation>					        
XML;

$payload = new \Spec\Model\Payload();
$payload->setContent($xml);

$handler = new \Spec\Handler\Wms\Shifter\Shipment($payload);
$handler->execute();
