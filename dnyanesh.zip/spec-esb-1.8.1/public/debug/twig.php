<?php

define("ROOT_PATH", realpath(__DIR__ . DIRECTORY_SEPARATOR . ".." . DIRECTORY_SEPARATOR . ".." . DIRECTORY_SEPARATOR));

/* Require vendor autoload  */
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "vendor" . DIRECTORY_SEPARATOR . "autoload.php";
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "application" . DIRECTORY_SEPARATOR . "bootstrap.php";

$loader = new \Twig_Loader_Filesystem(__DIR__ . DIRECTORY_SEPARATOR . "twig");
$twig = new \Twig_Environment($loader, array());
$template = $twig->loadTemplate("template/test.twig");
echo $template->render(array());