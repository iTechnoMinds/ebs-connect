<?php

/**
 * This is a health check script for external party to ping.
 * URI is external/healthcheck.
 * The mapping is managed in .htaccess.
 * 
 * @author Harry Lesmana <harrylesmana@singpost.com>
 * @author Dnyaneshwar <dnyaneshwarte@cybage.com>
 * @since 2018-06-19
 */

date_default_timezone_set("UTC");

$t = microtime(true);
$micro = sprintf("%06d", ($t - floor($t)) * 1000000);
$responseDate = new \DateTime(date('Y-m-d H:i:s.' . $micro, $t));

$responseArray = array(
    "code" => "200",
    "status_code" => "0",
    "node" => $_SERVER["SERVER_ADDR"],
    "id" => $responseDate->format("Ymd_His.u")
);

echo json_encode($responseArray);
