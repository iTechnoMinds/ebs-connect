<?php

define("ROOT_PATH", realpath(__DIR__ . DIRECTORY_SEPARATOR . ".." . DIRECTORY_SEPARATOR));

/* Require vendor autoload  */
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "vendor" . DIRECTORY_SEPARATOR . "autoload.php";
require_once ROOT_PATH . DIRECTORY_SEPARATOR . "application" . DIRECTORY_SEPARATOR . "bootstrap.php";

/**
 * Set global uncaught expection and fatal error handler.
 * @todo This might not be necessary afterall with error handler from Slim
 */
#set_exception_handler(array('\Spec\ErrorHandler', 'handleException'));
#register_shutdown_function(array('\Spec\ErrorHandler', 'handleShutdown'));

$app = new \Slim\Slim();
$app->config("debug", !\Spec\App::getConfig()->app->production);

$context = array(
    "class" => "index.php",
    "url" => $app->request->getUrl() . $app->request->getPathInfo(),
    "headers" => $app->request->headers(),
    "params" => $app->request->params()
);

/**
 * This is custom endpoint.
 * The declaration must be done before declaration of /:app/:context.
 */
$app->map("/external/custom/:listenerCode", function($paramListenerCode) use ($app, $context) {
    processRequestCustom($app, $paramListenerCode);
})->via("GET", "POST");

/**
 * This endpoint is provided to take payload from external system.
 * Mapping to eliminate the use of query string.
 */
$app->map("/:app/:context/client/:client/key/:key", function($paramApp, $paramContext, $paramClient, $paramKey) use($app, $context) {
    $headers = array(
        "contextCode" => "{$paramApp}-{$paramContext}",
        "authUser" => $paramClient,
        "authKey" => $paramKey,
    );
    processRequest($app, $context, $headers);
})->via("GET", "POST");

/**
 * This endpoint is provided to take payload from external system.
 */
$app->map("/:app/:context", function($paramApp, $paramContext) use($app, $context) {
    $authUser = $app->request->headers['spe-client'];
    if ($authUser == NULL) {
        $authUser = $app->request->get('spe-client');
    }
    $authKey = $app->request->headers('spe-apiKey');
    if ($authKey == NULL) {
        $authKey = $app->request->get('spe-apiKey');
    }
    $headers = array(
        "contextCode" => "{$paramApp}-{$paramContext}",
        "authUser" => $authUser,
        "authKey" => $authKey,
    );
    processRequest($app, $context, $headers);
})->via("GET", "POST");

/**
 * This endpoint is provided to take order from legacy Magento.
 * It listens to https://{host}/order and will translate the request into MIDZ payload.
 * Dependency to config file:
 * - magento.order.contextcode
 * - magento.order.authuser
 * - magento.order.authkey
 */
$app->map("/order", function() use ($app, $context) {
    $headers = array(
        "contextCode" => \Spec\App::getConfig()->magento->order->contextcode,
        "authUser" => \Spec\App::getConfig()->magento->order->authuser,
        "authKey" => \Spec\App::getConfig()->magento->order->authkey,
    );
    processRequest($app, $context, $headers);
})->via("GET", "POST");

/**
 * This endpoint is provided for internal use and should not be shared with external party.
 */
$app->map("/core+", function() use ($app, $context) {
    $headers = array(
        "contextCode" => $app->request->headers("contextCode"),
        "authUser" => $app->request->headers("authUser"),
        "authKey" => $app->request->headers("authKey"),
    );
    processRequest($app, $context, $headers);
})->via("GET", "POST");
/**
 * This endpoint is for newly launched products.
 */
$app->map("/releaseOrders", function() use ($app, $context) {
    $headers = array(
        "contextCode" => $app->request->headers("contextCode"),
        "authUser" => $app->request->headers("authUser"),
        "authKey" => $app->request->headers("authKey"),
    );
    processRequest($app, $context, $headers);
})->via("GET", "POST");

$app->error(function(\Exception $ex) use ($app, $context) {
    $app->response()->setStatus(403);
    \Spec\App::getLog("endpoint")->error($ex->getMessage(), $context);
    echo json_encode(array("code" => 403, "message" => $ex->getMessage()));
});

$app->notFound(function() use ($app, $context) {
    $app->response->setStatus(404);
    \Spec\App::getLog("endpoint")->info("404 Not found", $context);
    echo json_encode(array("code" => 404, "message" => "Not found"));
});

$app->run();

function processRequest($app, $context, $headers) {
    $payload = new \Spec\Model\Payload();
    $payload->setContentType('\Slim\Http\Request');
    $payload->setContent($app->request);
    $payload->addAttribute("contextCode", $headers["contextCode"]);
    $payload->addAttribute("authUser", $headers["authUser"]);
    $payload->addAttribute("authKey", $headers["authKey"]);
    $handler = new \Spec\Handler\Slim\HttpCore($payload);
    $handler->execute();
    $result = $handler->getResult();
    $responseData = array("code" => "200");
    if ($result !== NULL) {
        $responseData = array(
            "code" => "200",
            "status_code" => $result->getStatusCode(),
            "node" => $_SERVER["SERVER_ADDR"],
            "id" => $result->getOutputId()
        );
    }
    \Spec\App::getLog("endpoint")->info("200 OK", $context);
    echo json_encode($responseData);
}

/**
 * Process Custom Requests.
 * @param \Slim\Slim $app
 * @param string $listenerCode
 */
function processRequestCustom($app, $listenerCode) {
    $payload = new \Spec\Model\Payload();
    $payload->setContentType('\Slim\Http\Request');
    $payload->setContent($app->request);
    $payload->addAttribute("ListenerCode", $listenerCode);

    $handler = new \Spec\Handler\CustomListener\Router($payload);
    $result = $handler->execute();

    if ($result instanceof \Spec\Model\Result) {
        $app->response()->setBody($result->getMessage());
        $app->response()->setStatus($result->getStatusCode());
    } else {
        $app->response()->setBody("ERROR! Unable to define result type");
        $app->response()->setStatus("500");
    }
}
